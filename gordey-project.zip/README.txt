GORDEY VISUALS  -  Minecraft 1.21.11 (Fabric)

УСТАНОВКА
1. Распакуй архив Gordey-Client.zip в папку .minecraft
   (получатся .minecraft/versions/Gordey и .minecraft/mods).
2. Перезапусти лаунчер и выбери версию "Gordey".
   Если лаунчер хранит моды отдельно для каждой версии, скопируй папку mods
   в папку этой версии.

УПРАВЛЕНИЕ
Right Shift  - открыть меню (кнопку можно поменять в Interface -> Bind)
ЛКМ по модулю - вкл/выкл     ПКМ или "..." - настройки
Ctrl + F - поиск по модулям
В открытом меню HUD-элементы можно перетаскивать мышкой.
Настройки: .minecraft/config/gordey_visuals.json

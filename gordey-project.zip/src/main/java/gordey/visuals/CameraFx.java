package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Cinematic camera: pulls back while moving, smooths jumps / sneaking, optional hurt shake. */
public final class CameraFx {
    private CameraFx() { }

    static Fx.CameraFxMod mod;

    // ---- camera state captured every frame (used by world-space overlays)
    public static volatile double camX, camY, camZ;
    public static volatile float camYaw, camPitch;
    public static volatile long camMs;
    public static volatile float fovWorld = -1f;
    public static volatile float zoomTarget = 1f, zoomSpeed = 10f;
    private static float zoomCur = 1f;
    private static long fovHookMs, lastFovNs;
    private static boolean fovGot;

    public static void capture(Camera cam, Vec3d p) {
        camX = p.x; camY = p.y; camZ = p.z;
        camYaw = cam.getYaw(); camPitch = cam.getPitch();
        camMs = System.currentTimeMillis();
    }

    public static boolean cameraFresh() { return System.currentTimeMillis() - camMs < 300; }
    public static boolean fovHooked() { return System.currentTimeMillis() - fovHookMs < 500; }

    public static float fovHook(float f) {
        long ns = System.nanoTime();
        long now = System.currentTimeMillis();
        fovHookMs = now;
        if (ns - lastFovNs > 4_000_000L) {
            float dt = lastFovNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastFovNs) / 1e9f);
            zoomCur += (zoomTarget - zoomCur) * Math.min(1f, dt * zoomSpeed);
            fovGot = false;
        }
        lastFovNs = ns;
        float r = f * zoomCur;
        if (!fovGot) { fovWorld = r; fovGot = true; }
        return r;
    }

    public static float fovDeg() {
        float f = fovWorld;
        if (f > 1f && f < 170f) return f;
        return MinecraftClient.getInstance().options.getFov().getValue();
    }

    /** Projects a world point to scaled screen coordinates. out = {x, y, depth}. */
    public static boolean project(double wx, double wy, double wz, int sw, int sh, float[] out) {
        if (!cameraFresh()) return false;
        double dx = wx - camX, dy = wy - camY, dz = wz - camZ;
        double yaw = Math.toRadians(camYaw), pitch = Math.toRadians(camPitch);
        double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
        double fx = -sy * cp, fy = -sp, fz = cy * cp;
        double rx = -cy, rz = -sy;
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        double z = dx * fx + dy * fy + dz * fz;
        if (z < 0.05) return false;
        double x = dx * rx + dz * rz;
        double y = dx * ux + dy * uy + dz * uz;
        double t = Math.tan(Math.toRadians(fovDeg()) / 2.0);
        double aspect = (double) sw / sh;
        out[0] = (float) (sw / 2.0 + x / (z * t * aspect) * sw / 2.0);
        out[1] = (float) (sh / 2.0 - y / (z * t) * sh / 2.0);
        out[2] = (float) z;
        return true;
    }

    public static double pxPerBlock(double depth, int sh) {
        double t = Math.tan(Math.toRadians(fovDeg()) / 2.0);
        return (sh / 2.0) / (depth * t);
    }
    private static float back;
    private static double smY;
    private static boolean init;
    private static long lastNs;

    public static Vec3d apply(Camera cam, Vec3d p) {
        Fx.CameraFxMod m = mod;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (m == null || !m.enabled || p == null || mc.player == null || mc.world == null) { init = false; return null; }
        if (mc.getCameraEntity() != mc.player) { init = false; return null; }
        if (cam.isThirdPerson() && m.firstOnly.value) { init = false; return null; }

        long ns = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
        lastNs = ns;

        double rawY = p.y;
        if (!init || Math.abs(rawY - smY) > 3.0) { smY = rawY; back = 0f; init = true; }
        smY += (rawY - smY) * Math.min(1f, dt * m.vertical.asFloat());
        double dy = m.smoothJump.value ? Math.max(-0.7, Math.min(0.7, smY - rawY)) : 0.0;

        float target = (float) (m.pull.value * Math.min(1.3, Stats.bps / 6.0));
        back += (target - back) * Math.min(1f, dt * m.speed.asFloat());

        double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
        double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);

        double d = back;
        Vec3d np = null;
        for (int i = 0; i < 5; i++) {
            Vec3d c = new Vec3d(p.x - fx * d, p.y + dy - fy * d, p.z - fz * d);
            BlockPos bp = BlockPos.ofFloored(c.x, c.y, c.z);
            if (mc.world.getBlockState(bp).getCollisionShape(mc.world, bp).isEmpty()) { np = c; break; }
            d *= 0.5;
        }
        if (np == null) np = new Vec3d(p.x, p.y + dy, p.z);

        if (m.shake.value && mc.player.hurtTime > 0) {
            double t = System.currentTimeMillis() / 1000.0;
            double k = m.shakeAmt.value * 0.05 * mc.player.hurtTime;
            np = np.add(Math.sin(t * 61) * k, Math.sin(t * 73) * k, Math.sin(t * 53) * k);
        }
        return np;
    }
}

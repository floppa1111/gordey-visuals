package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class Extra {
    private Extra() { }

    static int healthColor(float r) {
        r = Math.max(0f, Math.min(1f, r));
        if (r > 0.5f) return Gfx.lerp(0xFFFFD84D, 0xFF4DFF7A, (r - 0.5f) * 2f);
        return Gfx.lerp(0xFFFF4040, 0xFFFFD84D, r * 2f);
    }

    static String f1(float v) { return String.format(Locale.ROOT, "%.1f", v); }

    static int pingOf(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null) return 0;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }

    // ================================================================ TARGET HUD
    public static final class TargetHudMod extends HudModule {
        final Setting.Mode source = add(new Setting.Mode("Target", 2, "Last hit", "Crosshair", "Both"));
        final Setting.Num hold = add(new Setting.Num("Hold time (s)", 4, 1, 10, 0.5));
        final Setting.Mode layoutMode = add(new Setting.Mode("Style", 0, "Classic", "Compact", "Minimal"));
        final Setting.Num width = add(new Setting.Num("Width", 150, 110, 220, 5));
        final Setting.Bool showHead = add(new Setting.Bool("Head", true));
        final Setting.Bool headFrame = add(new Setting.Bool("Head frame", true));
        final Setting.Bool showName = add(new Setting.Bool("Name", true));
        final Setting.Mode nameColor = add(new Setting.Mode("Name color", 0, "White", "Theme", "Health"));
        final Setting.Mode hpText = add(new Setting.Mode("HP text", 0, "Number", "Percent", "Both", "None"));
        final Setting.Mode barStyle = add(new Setting.Mode("Bar style", 1, "Solid", "Gradient", "Segmented"));
        final Setting.Mode barColor = add(new Setting.Mode("Bar color", 0, "Health", "Theme"));
        final Setting.Bool smooth = add(new Setting.Bool("Smooth bar", true));
        final Setting.Bool absorb = add(new Setting.Bool("Absorption", true));
        final Setting.Bool showArmor = add(new Setting.Bool("Armor", true));
        final Setting.Bool showDistance = add(new Setting.Bool("Distance", true));
        final Setting.Bool showPing = add(new Setting.Bool("Ping", false));
        final Setting.Bool showHeld = add(new Setting.Bool("Held item", true));
        final Setting.Bool slide = add(new Setting.Bool("Slide animation", true));

        private LivingEntity current;
        private float shownHp, appear;
        private long lastNs;

        public TargetHudMod() {
            super("TargetHUD", "Shows name, head and health of the player you hit.");
            enabled = true;
        }

        @Override protected int defaultX(int sw) { return sw / 2 + 16; }
        @Override protected int defaultY(int sh) { return sh / 2 + 16; }

        private LivingEntity resolve(MinecraftClient mc) {
            long now = System.currentTimeMillis();
            LivingEntity res = null;
            if (!source.is("Crosshair")) {
                LivingEntity l = Stats.lastTarget;
                if (l != null && l.isAlive() && now - Stats.lastHitMs <= hold.value * 1000) res = l;
            }
            if (res == null && !source.is("Last hit")) {
                if (mc.targetedEntity instanceof LivingEntity le && le != mc.player) res = le;
            }
            return res;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            long ns = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
            lastNs = ns;
            boolean editing = mc.currentScreen instanceof GordeyScreen;

            LivingEntity found = resolve(mc);
            if (found != null) {
                if (found != current) { current = found; shownHp = found.getHealth(); }
                appear = Math.min(1f, appear + dt * 6f);
            } else appear = Math.max(0f, appear - dt * 6f);

            LivingEntity tgt = current;
            if (tgt == null || (appear <= 0.01f && !editing)) {
                if (!editing) { w = 0; h = 0; return; }
                tgt = mc.player;
                shownHp = tgt.getHealth();
                appear = 1f;
            }

            float hp = tgt.getHealth(), max = Math.max(1f, tgt.getMaxHealth()), abs = tgt.getAbsorptionAmount();
            if (smooth.value) shownHp += (hp - shownHp) * Math.min(1f, dt * 8f); else shownHp = hp;
            float ratio = Math.max(0f, Math.min(1f, shownHp / max));
            int hpCol = healthColor(ratio);

            int pad = 5;
            boolean mini = layoutMode.is("Minimal"), compact = layoutMode.is("Compact");
            int headS = (!showHead.value || mini) ? 0 : (compact ? 20 : 32);
            int barH = mini ? 5 : compact ? 4 : 6;
            ItemStack held = tgt.getMainHandStack();
            int itemW = (showHeld.value && !mini && !held.isEmpty()) ? 18 : 0;
            boolean info = !mini && (showArmor.value || showDistance.value || showPing.value);
            int textBlock = 11 + barH + 3 + (info ? 11 : 0) - (info ? 0 : 3);
            int ch = pad * 2 + Math.max(headS, textBlock);
            int cw = width.asInt();
            w = cw; h = ch;
            int px = left();
            int py = y + Math.round((1f - Gfx.easeOut(appear)) * (slide.value ? 8f : 0f));

            panel(ctx, px, py, cw, ch);
            int ac = accent();

            int hx = px + pad + 2, hy = py + (ch - headS) / 2;
            if (headS > 0) {
                if (headFrame.value) ctx.fill(hx - 1, hy - 1, hx + headS + 1, hy + headS + 1, Gfx.alpha(ac, 210));
                Heads.draw(ctx, mc, tgt, hx, hy, headS, ac);
            }
            int ix = px + pad + 2 + (headS > 0 ? headS + 5 : 0);
            int iw = px + cw - pad - itemW - ix;
            int ty = py + pad + (Math.max(headS, textBlock) - textBlock) / 2;

            String ht = switch (hpText.get()) {
                case "Number" -> f1(shownHp);
                case "Percent" -> Math.round(ratio * 100) + "%";
                case "Both" -> f1(shownHp) + " (" + Math.round(ratio * 100) + "%)";
                default -> "";
            };
            int htw = tr.getWidth(ht);
            if (showName.value) {
                int col = nameColor.is("Theme") ? ac : nameColor.is("Health") ? hpCol : 0xFFFFFFFF;
                String nm = tr.trimToWidth(tgt.getName().getString(), Math.max(20, iw - htw - 6));
                fx(ctx, nm, ix, ty, col);
            }
            if (!ht.isEmpty()) ctx.drawText(tr, ht, ix + iw - htw, ty, 0xFFFFFFFF, true);

            int by = ty + 11;
            int base = barColor.is("Theme") ? ac : hpCol;
            Gfx.round(ctx, ix, by, iw, barH, 2, 0xFF1A1A22);
            int fw = Math.round(iw * ratio);
            if (barStyle.is("Solid")) {
                Gfx.round(ctx, ix, by, fw, barH, 2, base);
            } else if (barStyle.is("Gradient")) {
                int dark = Gfx.lerp(base, 0xFF000000, 0.45f);
                for (int i = 0; i < fw; i += 2) ctx.fill(ix + i, by, ix + Math.min(i + 2, fw), by + barH, Gfx.lerp(dark, base, i / (float) iw));
            } else {
                int segs = 10, gap = 1, segW = (iw - gap * (segs - 1)) / segs;
                for (int i = 0; i < segs; i++) {
                    int sx = ix + i * (segW + gap);
                    ctx.fill(sx, by, sx + segW, by + barH, 0xFF1A1A22);
                    float f = Math.max(0f, Math.min(1f, ratio * segs - i));
                    if (f > 0) ctx.fill(sx, by, sx + Math.max(1, Math.round(segW * f)), by + barH, base);
                }
            }
            if (absorb.value && abs > 0) {
                int aw = Math.round(iw * Math.min(1f, abs / max));
                ctx.fill(ix, by, ix + aw, by + Math.max(1, barH / 2), 0xFFFFD34D);
            }

            if (info) {
                int iy = by + barH + 3, cx = ix;
                if (showArmor.value) { String s = "Armor " + tgt.getArmor(); ctx.drawText(tr, s, cx, iy, 0xFFB4C8E6, false); cx += tr.getWidth(s) + 8; }
                if (showDistance.value) { String s = f1(mc.player.distanceTo(tgt)) + "m"; ctx.drawText(tr, s, cx, iy, 0xFFA8A8B3, false); cx += tr.getWidth(s) + 8; }
                if (showPing.value && tgt instanceof net.minecraft.entity.player.PlayerEntity pe && mc.getNetworkHandler() != null) {
                    PlayerListEntry en = mc.getNetworkHandler().getPlayerListEntry(pe.getUuid());
                    if (en != null) ctx.drawText(tr, en.getLatency() + "ms", cx, iy, 0xFFA8A8B3, false);
                }
            }
            if (itemW > 0) ctx.drawItem(held, px + cw - pad - 16, py + (ch - 16) / 2);
        }
    }

    // ================================================================ CLOCK
    public static final class HeldItemMod extends HudModule {
        public HeldItemMod() { super("HeldItem", "Item in your hand with durability."); }
        @Override protected int defaultX(int sw) { return sw / 2 - 60; }
        @Override protected int defaultY(int sh) { return sh - 78; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            ItemStack s = mc.player.getMainHandStack();
            if (s.isEmpty()) { w = 0; h = 0; return; }
            TextRenderer tr = mc.textRenderer;
            String nm = s.getName().getString();
            String extra = s.isDamageable() ? (s.getMaxDamage() - s.getDamage()) + "/" + s.getMaxDamage() : (s.getCount() > 1 ? "x" + s.getCount() : "");
            int cw = 8 + 16 + 5 + Math.max(tr.getWidth(nm), tr.getWidth(extra)) + 8;
            int ch = 26;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            ctx.drawItem(s, px + 8, py + 5);
            ctx.drawText(tr, nm, px + 29, py + 4, 0xFFFFFFFF, true);
            if (!extra.isEmpty()) ctx.drawText(tr, extra, px + 29, py + 14, accent(), false);
        }
    }

    // ================================================================ SERVER INFO
    public static final class ServerInfoMod extends HudModule {
        final Setting.Bool showIp = add(new Setting.Bool("Address", true));
        final Setting.Bool showPlayers = add(new Setting.Bool("Players", true));
        final Setting.Bool showPing = add(new Setting.Bool("Ping", true));
        final Setting.Bool showVersion = add(new Setting.Bool("Version", false));

        public ServerInfoMod() { super("ServerInfo", "Server address, online and ping."); }
        @Override protected int defaultY(int sh) { return sh - 100; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<String[]> rows = new ArrayList<>();
            var si = mc.getCurrentServerEntry();
            if (showIp.value) rows.add(new String[]{"Server", Player.StreamerModeMod.server() ? "hidden" : (si != null ? si.address : "Singleplayer")});
            if (showPlayers.value) rows.add(new String[]{"Online", String.valueOf(mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerList().size() : 0)});
            if (showPing.value) rows.add(new String[]{"Ping", pingOf(mc) + " ms"});
            if (showVersion.value) rows.add(new String[]{"Version", "1.21.11"});
            if (rows.isEmpty()) { w = 0; h = 0; return; }
            drawRows(ctx, tr, rows);
        }

        private void drawRows(DrawContext ctx, TextRenderer tr, List<String[]> rows) {
            int pad = 6, rowH = 11, cw = 90;
            for (String[] r : rows) cw = Math.max(cw, tr.getWidth(r[0]) + tr.getWidth(r[1]) + pad * 2 + 14);
            int ch = rows.size() * rowH + pad * 2 - 2;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < rows.size(); i++) {
                int ry = py + pad - 1 + i * rowH;
                ctx.drawText(tr, rows.get(i)[0], px + pad + 2, ry, 0xFFA8A8B3, false);
                ctx.drawText(tr, rows.get(i)[1], px + cw - pad - tr.getWidth(rows.get(i)[1]), ry, 0xFFFFFFFF, true);
            }
        }
    }

    // ================================================================ WORLD INFO
    public static final class WorldInfoMod extends HudModule {
        final Setting.Bool showBiome = add(new Setting.Bool("Biome", true));
        final Setting.Bool showLight = add(new Setting.Bool("Light level", true));
        final Setting.Bool showDim = add(new Setting.Bool("Dimension", true));
        final Setting.Bool showChunk = add(new Setting.Bool("Chunk", false));

        public WorldInfoMod() { super("WorldInfo", "Biome, light level and dimension."); }
        @Override protected int defaultY(int sh) { return sh - 150; }

        private static String pretty(String s) {
            String t = s.replace('_', ' ');
            return t.isEmpty() ? t : Character.toUpperCase(t.charAt(0)) + t.substring(1);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<String[]> rows = new ArrayList<>();
            if (showBiome.value) {
                String b = mc.world.getBiome(mc.player.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                rows.add(new String[]{"Biome", pretty(b)});
            }
            if (showLight.value) rows.add(new String[]{"Light", String.valueOf(mc.world.getLightLevel(mc.player.getBlockPos()))});
            if (showDim.value) rows.add(new String[]{"Dimension", pretty(mc.world.getRegistryKey().getValue().getPath())});
            if (showChunk.value && !Player.StreamerModeMod.coords()) rows.add(new String[]{"Chunk", (mc.player.getBlockX() >> 4) + ", " + (mc.player.getBlockZ() >> 4)});
            if (rows.isEmpty()) { w = 0; h = 0; return; }
            int pad = 6, rowH = 11, cw = 90;
            for (String[] r : rows) cw = Math.max(cw, tr.getWidth(r[0]) + tr.getWidth(r[1]) + pad * 2 + 14);
            int ch = rows.size() * rowH + pad * 2 - 2;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < rows.size(); i++) {
                int ry = py + pad - 1 + i * rowH;
                ctx.drawText(tr, rows.get(i)[0], px + pad + 2, ry, 0xFFA8A8B3, false);
                ctx.drawText(tr, rows.get(i)[1], px + cw - pad - tr.getWidth(rows.get(i)[1]), ry, 0xFFFFFFFF, true);
            }
        }
    }

    // ================================================================ COMBO COUNTER
    public static final class ComboCounterMod extends HudModule {
        final Setting.Num expire = add(new Setting.Num("Reset after (s)", 3, 1, 8, 0.5));
        final Setting.Bool showTotal = add(new Setting.Bool("Total hits", true));

        public ComboCounterMod() { super("ComboCounter", "Counts your consecutive hits."); }
        @Override protected int defaultX(int sw) { return sw / 2 + 16; }
        @Override protected int defaultY(int sh) { return sh / 2 + 80; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean active = System.currentTimeMillis() - Stats.comboMs <= expire.value * 1000;
            String c = "Combo  x" + (active ? Stats.combo : 0);
            String t = "Hits  " + Stats.hits;
            int cw = Math.max(tr.getWidth(c), showTotal.value ? tr.getWidth(t) : 0) + 20;
            int ch = 14 + (showTotal.value ? 11 : 0);
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            ctx.drawText(tr, c, px + 10, py + 5, active ? accent() : 0xFFA8A8B3, true);
            if (showTotal.value) ctx.drawText(tr, t, px + 10, py + 16, 0xFFA8A8B3, false);
        }
    }

    // ================================================================ COOLDOWN BAR
    public static final class CooldownBarMod extends HudModule {
        final Setting.Num length = add(new Setting.Num("Length", 60, 30, 140, 5));
        final Setting.Bool always = add(new Setting.Bool("Always show", false));

        public CooldownBarMod() {
            super("CooldownBar", "Attack cooldown bar under the crosshair.");
            style.remove(rounding);
            style.remove(effect);
        }
        @Override protected int defaultX(int sw) { return sw / 2 - 30; }
        @Override protected int defaultY(int sh) { return sh / 2 + 12; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            float p = mc.player.getAttackCooldownProgress(0f);
            boolean editing = mc.currentScreen instanceof GordeyScreen;
            if (p >= 1f && !always.value && !editing) { w = 0; h = 0; return; }
            int cw = length.asInt(), ch = 4;
            w = cw; h = ch;
            int px = left(), py = y;
            ctx.fill(px, py, px + cw, py + ch, bgColor());
            ctx.fill(px, py, px + Math.round(cw * Math.min(1f, p)), py + ch, p >= 1f ? 0xFF4DFF7A : accent());
        }
    }

    // ================================================================ CROSSHAIR RING
    public static final class CrosshairRingMod extends HudModule {
        final Setting.Mode shape = add(new Setting.Mode("Shape", 0, "Ring", "Square", "Brackets", "Dot"));
        final Setting.Num size = add(new Setting.Num("Size", 7, 3, 16, 1));
        final Setting.Num thick = add(new Setting.Num("Thickness", 1, 1, 3, 1));
        final Setting.Bool react = add(new Setting.Bool("React to target", true));
        final Setting.Col targetCol = add(new Setting.Col("Target color", 0f, 0.85f, 1f));

        public CrosshairRingMod() {
            super("CrosshairRing", "Custom shape around the crosshair.");
            style.remove(opacity);
            style.remove(rounding);
            style.remove(effect);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
            int col = accent();
            if (react.value && mc.targetedEntity instanceof LivingEntity) col = 0xFF000000 | targetCol.rgb();
            int r = size.asInt(), t = thick.asInt();
            switch (shape.get()) {
                case "Ring" -> {
                    int pts = 12 + r * 6;
                    for (int i = 0; i < pts; i++) {
                        double a = i * 2 * Math.PI / pts;
                        int px = cx + (int) Math.round(Math.cos(a) * r), py = cy + (int) Math.round(Math.sin(a) * r);
                        ctx.fill(px, py, px + t, py + t, col);
                    }
                }
                case "Square" -> Gfx.outline(ctx, cx - r, cy - r, r * 2 + 1, r * 2 + 1, 0, col);
                case "Brackets" -> {
                    int l = Math.max(2, r / 2 + 1);
                    ctx.fill(cx - r, cy - r, cx - r + l, cy - r + t, col); ctx.fill(cx - r, cy - r, cx - r + t, cy - r + l, col);
                    ctx.fill(cx + r - l + 1, cy - r, cx + r + 1, cy - r + t, col); ctx.fill(cx + r + 1 - t, cy - r, cx + r + 1, cy - r + l, col);
                    ctx.fill(cx - r, cy + r + 1 - t, cx - r + l, cy + r + 1, col); ctx.fill(cx - r, cy + r - l + 1, cx - r + t, cy + r + 1, col);
                    ctx.fill(cx + r - l + 1, cy + r + 1 - t, cx + r + 1, cy + r + 1, col); ctx.fill(cx + r + 1 - t, cy + r - l + 1, cx + r + 1, cy + r + 1, col);
                }
                default -> ctx.fill(cx - t, cy - t, cx + t + 1, cy + t + 1, col);
            }
        }
    }

    // ================================================================ LOW HEALTH VIGNETTE
    public static final class LowHealthMod extends HudModule {
        final Setting.Num below = add(new Setting.Num("Below HP", 8, 2, 16, 1));
        final Setting.Num strength = add(new Setting.Num("Strength", 110, 30, 220, 10));
        final Setting.Num edge = add(new Setting.Num("Edge size", 40, 20, 90, 5));
        final Setting.Bool pulse = add(new Setting.Bool("Pulse", true));

        public LowHealthMod() {
            super("LowHealthVignette", "Red screen edges when your health is low.");
            style.clear();
            backdrop = true;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            float hp = mc.player.getHealth();
            if (hp > below.value) return;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            float severity = Math.max(0.35f, 1f - hp / (float) below.value);
            float pul = pulse.value ? 0.65f + 0.35f * (float) Math.sin(System.currentTimeMillis() / 250.0) : 1f;
            float base = strength.asFloat() * severity * pul;
            int e = edge.asInt();
            for (int i = 0; i < e; i += 2) {
                float k = 1f - i / (float) e;
                int a = Math.max(0, Math.min(255, (int) (base * k * k)));
                int col = (a << 24) | 0xFF2020;
                ctx.fill(0, i, sw, i + 2, col);
                ctx.fill(0, sh - i - 2, sw, sh - i, col);
                ctx.fill(i, 0, i + 2, sh, col);
                ctx.fill(sw - i - 2, 0, sw - i, sh, col);
            }
        }
    }

    // ================================================================ WELCOME (Other)
    public static final class WelcomeMod extends Module {
        final Setting.Mode greeting = add(new Setting.Mode("Greeting", 0, "Welcome", "Hello", "Good luck"));

        public WelcomeMod() {
            super("Welcome", "Greets you with a toast when you join a world.", Category.OTHER);
            enabled = true;
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (Stats.justJoined) Notifier.push("Gordey Visuals", greeting.get() + (Player.StreamerModeMod.nick() ? "" : ", " + mc.player.getName().getString()), Theme.accent());
        }
    }
}

package gordey.visuals;

import gordey.visuals.mixin.ParticleAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.particle.Particle;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

public final class Fx {
    private Fx() { }

    // ================================================================ SMOOTH CAMERA
    public static final class CameraFxMod extends Module {
        final Setting.Num pull = add(new Setting.Num("Pull-back", 0.45, 0, 1.5, 0.05));
        final Setting.Num speed = add(new Setting.Num("Pull smoothing", 7, 2, 20, 1));
        final Setting.Bool smoothJump = add(new Setting.Bool("Smooth jump", true));
        final Setting.Num vertical = add(new Setting.Num("Jump smoothing", 12, 4, 30, 1));
        final Setting.Bool shake = add(new Setting.Bool("Hurt shake", false));
        final Setting.Num shakeAmt = add(new Setting.Num("Shake strength", 0.5, 0.1, 2.0, 0.1));
        final Setting.Bool firstOnly = add(new Setting.Bool("First person only", true));

        public CameraFxMod() {
            super("SmoothCamera", "Camera pulls back while you move and rises smoothly on jumps.", Category.VISUALS);
            shakeAmt.visible = () -> shake.value;
            CameraFx.mod = this;
        }
    }

    // ================================================================ ATMOSPHERE (world particles)
    public static final class AtmosphereMod extends Module {
        final Setting.Mode type = add(new Setting.Mode("Type", 0, "Lanterns", "Dots", "Hearts", "Petals", "Snow", "Fireflies", "Stars", "Notes", "Souls", "Totems"));
        final Setting.Num amount = add(new Setting.Num("Amount", 3, 1, 12, 1));
        final Setting.Num radius = add(new Setting.Num("Radius", 16, 5, 30, 1));
        final Setting.Num height = add(new Setting.Num("Height", 8, 2, 16, 1));
        final Setting.Num size = add(new Setting.Num("Size", 1.2, 0.4, 3.5, 0.1));
        final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.2, 3.0, 0.1));
        final Setting.Num life = add(new Setting.Num("Lifetime (s)", 8, 2, 25, 1));
        final Setting.Mode colorMode = add(new Setting.Mode("Color", 0, "Theme", "Custom", "Rainbow", "Random", "Original"));
        final Setting.Col custom = add(new Setting.Col("Custom color", 0.9f, 0.6f, 1f));

        public AtmosphereMod() {
            super("Atmosphere", "Floating lanterns, dots, hearts and more around you.", Category.VISUALS);
            custom.visible = () -> colorMode.is("Custom");
        }

        private float[] pickColor() {
            if (colorMode.is("Original")) return null;
            int rgb;
            if (colorMode.is("Theme")) rgb = Theme.accent();
            else if (colorMode.is("Custom")) rgb = custom.rgb();
            else if (colorMode.is("Rainbow")) rgb = java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 4000L) / 4000f, 0.7f, 1f);
            else rgb = java.awt.Color.HSBtoRGB(ThreadLocalRandom.current().nextFloat(), 0.65f, 1f);
            return new float[]{((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f};
        }

        private static void tint(Particle p, float[] c) {
            try {
                ParticleAccessor a = (ParticleAccessor) (Object) p;
                a.gordey$setRed(c[0]);
                a.gordey$setGreen(c[1]);
                a.gordey$setBlue(c[2]);
            } catch (Throwable ignored) { }
        }

        private static double rnd(double a, double b) { return a + ThreadLocalRandom.current().nextDouble() * (b - a); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (mc.world == null || mc.particleManager == null) return;
            double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
            double sp = speed.value;
            for (int i = 0; i < amount.asInt(); i++) {
                double a = rnd(0, Math.PI * 2), r = radius.value * Math.sqrt(ThreadLocalRandom.current().nextDouble());
                double x = px + Math.cos(a) * r, z = pz + Math.sin(a) * r;
                double y = py - 1 + rnd(0, height.value);
                ParticleEffect fx;
                double vx = 0, vy = 0, vz = 0;
                switch (type.get()) {
                    case "Lanterns" -> { fx = ParticleTypes.FLAME; vx = rnd(-0.004, 0.004) * sp; vz = rnd(-0.004, 0.004) * sp; vy = rnd(0.015, 0.035) * sp; }
                    case "Dots" -> { fx = ParticleTypes.END_ROD; vx = rnd(-0.01, 0.01) * sp; vy = rnd(-0.005, 0.015) * sp; vz = rnd(-0.01, 0.01) * sp; }
                    case "Hearts" -> fx = ParticleTypes.HEART;
                    case "Petals" -> { fx = ParticleTypes.CHERRY_LEAVES; y = py + rnd(2, height.value + 4); vx = rnd(-0.02, 0.02) * sp; vz = rnd(-0.02, 0.02) * sp; }
                    case "Snow" -> { fx = ParticleTypes.SNOWFLAKE; y = py + rnd(2, height.value + 4); vx = rnd(-0.01, 0.01) * sp; vz = rnd(-0.01, 0.01) * sp; }
                    case "Fireflies" -> { fx = ParticleTypes.END_ROD; vx = rnd(-0.015, 0.015) * sp; vy = rnd(-0.008, 0.008) * sp; vz = rnd(-0.015, 0.015) * sp; }
                    case "Stars" -> { fx = ParticleTypes.END_ROD; vy = rnd(0.0, 0.004) * sp; }
                    case "Notes" -> { fx = ParticleTypes.NOTE; vx = ThreadLocalRandom.current().nextDouble(); }
                    case "Souls" -> { fx = ParticleTypes.SOUL_FIRE_FLAME; vy = rnd(0.015, 0.03) * sp; }
                    default -> { fx = ParticleTypes.TOTEM_OF_UNDYING; vx = rnd(-0.02, 0.02) * sp; vy = rnd(0.0, 0.03) * sp; vz = rnd(-0.02, 0.02) * sp; }
                }
                Particle p = mc.particleManager.addParticle(fx, x, y, z, vx, vy, vz);
                if (p == null) continue;
                float s = size.asFloat() * (type.is("Fireflies") ? 0.45f : 1f);
                p.scale(s);
                p.setMaxAge((int) (life.value * 20 * (type.is("Hearts") ? 0.4 : 1.0)));
                float[] c = pickColor();
                if (c != null && !type.is("Hearts") && !type.is("Notes")) tint(p, c);
            }
        }
    }

    // ================================================================ SCREEN TINT
    public static final class ScreenTintMod extends HudModule {
        final Setting.Mode preset = add(new Setting.Mode("Preset", 0, "Warm", "Cool", "Sunset", "Mint", "Night", "Custom"));
        final Setting.Col custom = add(new Setting.Col("Custom color", 0.75f, 0.6f, 1f));
        final Setting.Num intensity = add(new Setting.Num("Intensity", 40, 0, 120, 5));
        final Setting.Bool vignette = add(new Setting.Bool("Vignette", true));
        final Setting.Num vigStrength = add(new Setting.Num("Vignette strength", 120, 30, 220, 10));
        final Setting.Bool letterbox = add(new Setting.Bool("Cinema bars", false));
        final Setting.Num barSize = add(new Setting.Num("Bar size", 30, 10, 90, 5));

        public ScreenTintMod() {
            super("ScreenTint", "Color grading, vignette and cinema bars.");
            style.clear();
            backdrop = true;
            custom.visible = () -> preset.is("Custom");
            vigStrength.visible = () -> vignette.value;
            barSize.visible = () -> letterbox.value;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int rgb = switch (preset.get()) {
                case "Warm" -> 0xFF9A3C;
                case "Cool" -> 0x3C8CFF;
                case "Sunset" -> 0xFF5A8C;
                case "Mint" -> 0x3CFFB4;
                case "Night" -> 0x1A2A6A;
                default -> custom.rgb();
            };
            if (intensity.asInt() > 0) ctx.fill(0, 0, sw, sh, (intensity.asInt() << 24) | rgb);
            if (vignette.value) {
                int e = 60;
                for (int i = 0; i < e; i += 2) {
                    float k = 1f - i / (float) e;
                    int col = (Math.min(255, (int) (vigStrength.value * k * k)) << 24);
                    ctx.fill(0, i, sw, i + 2, col);
                    ctx.fill(0, sh - i - 2, sw, sh - i, col);
                    ctx.fill(i, 0, i + 2, sh, col);
                    ctx.fill(sw - i - 2, 0, sw - i, sh, col);
                }
            }
            if (letterbox.value) {
                int b = barSize.asInt();
                ctx.fill(0, 0, sw, b, 0xFF000000);
                ctx.fill(0, sh - b, sw, sh, 0xFF000000);
            }
        }
    }

    // ================================================================ HIT MARKER
    public static final class HitMarkerMod extends HudModule {
        final Setting.Mode shape = add(new Setting.Mode("Shape", 0, "X", "Plus", "Ring"));
        final Setting.Num size = add(new Setting.Num("Size", 7, 3, 16, 1));
        final Setting.Num duration = add(new Setting.Num("Duration (ms)", 350, 150, 900, 50));

        public HitMarkerMod() {
            super("HitMarker", "Animated marker on the crosshair when you hit something.");
            style.remove(opacity);
            style.remove(rounding);
            style.remove(effect);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            long age = System.currentTimeMillis() - Stats.lastHitMs;
            boolean editing = mc.currentScreen instanceof GordeyScreen;
            if (age > duration.value && !editing) return;
            float k = editing ? 0.4f : age / (float) duration.value;
            int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
            int col = Gfx.alpha(accent(), (int) (255 * (1f - k)));
            int gap = 3 + Math.round(k * 4), len = size.asInt();
            if (shape.is("X")) {
                for (int i = gap; i < gap + len; i++) {
                    ctx.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, col);
                    ctx.fill(cx - i, cy + i, cx - i + 1, cy + i + 1, col);
                    ctx.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, col);
                    ctx.fill(cx - i, cy - i, cx - i + 1, cy - i + 1, col);
                }
            } else if (shape.is("Plus")) {
                for (int i = gap; i < gap + len; i++) {
                    ctx.fill(cx + i, cy, cx + i + 1, cy + 1, col); ctx.fill(cx - i, cy, cx - i + 1, cy + 1, col);
                    ctx.fill(cx, cy + i, cx + 1, cy + i + 1, col); ctx.fill(cx, cy - i, cx + 1, cy - i + 1, col);
                }
            } else {
                int r = gap + len / 2, pts = 40;
                for (int i = 0; i < pts; i++) {
                    double a = i * 2 * Math.PI / pts;
                    int px = cx + (int) Math.round(Math.cos(a) * r), py = cy + (int) Math.round(Math.sin(a) * r);
                    ctx.fill(px, py, px + 1, py + 1, col);
                }
            }
        }
    }

    // ================================================================ STATUS FLAGS
    public static final class StatusFlagsMod extends HudModule {
        public StatusFlagsMod() { super("StatusFlags", "Sprinting, sneaking, flying and swimming chips."); }
        @Override protected int defaultX(int sw) { return sw / 2 - 90; }
        @Override protected int defaultY(int sh) { return sh - 66; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<String> chips = new ArrayList<>();
            var p = mc.player;
            if (p.isSprinting()) chips.add("Sprinting");
            if (p.isSneaking()) chips.add("Sneaking");
            if (p.getAbilities().flying) chips.add("Flying");
            if (p.isSwimming()) chips.add("Swimming");
            if (chips.isEmpty() && mc.currentScreen instanceof GordeyScreen) chips.add("Sprinting");
            if (chips.isEmpty()) { w = 0; h = 0; return; }
            int cw = 6, ch = 15;
            for (String s : chips) cw += tr.getWidth(s) + 8;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            int cx = px + 6;
            for (String s : chips) {
                ctx.fill(cx - 3, py + 6, cx - 1, py + 9, accent());
                ctx.drawText(tr, s, cx + 1, py + 4, 0xFFFFFFFF, true);
                cx += tr.getWidth(s) + 8;
            }
        }
    }

    // ================================================================ PICKUP TOASTS (Other)
    public static final class PickupToastsMod extends Module {
        final Setting.Bool losses = add(new Setting.Bool("Show losses", false));
        private Map<String, Integer> last = new HashMap<>();
        private boolean ready;
        private int t;

        public PickupToastsMod() { super("PickupToasts", "Toast when you pick up items.", Category.OTHER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (Stats.justJoined) { ready = false; last = new HashMap<>(); }
            if (++t % 6 != 0) return;
            Map<String, Integer> cur = new HashMap<>();
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (st.isEmpty()) continue;
                cur.merge(st.getName().getString(), st.getCount(), Integer::sum);
            }
            if (ready) {
                int shown = 0;
                for (Map.Entry<String, Integer> e : cur.entrySet()) {
                    int d = e.getValue() - last.getOrDefault(e.getKey(), 0);
                    if (d > 0 && shown < 3) { Notifier.push("+" + d + "  " + e.getKey(), "Picked up", Theme.accent()); shown++; }
                }
                if (losses.value) {
                    for (Map.Entry<String, Integer> e : last.entrySet()) {
                        int d = last.get(e.getKey()) - cur.getOrDefault(e.getKey(), 0);
                        if (d > 0 && shown < 3) { Notifier.push("-" + d + "  " + e.getKey(), "Lost", 0xFFFF6060); shown++; }
                    }
                }
            }
            last = cur;
            ready = true;
        }
    }

    // ================================================================ DURABILITY WARNING (Other)
    public static final class DurabilityWarningMod extends Module {
        final Setting.Num threshold = add(new Setting.Num("Warn below (%)", 15, 5, 50, 5));
        private final Set<String> warned = new HashSet<>();
        private int t;

        public DurabilityWarningMod() { super("DurabilityWarning", "Warns when armor or tool is almost broken.", Category.OTHER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (++t % 20 != 0) return;
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
            for (EquipmentSlot s : slots) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (st.isEmpty() || !st.isDamageable()) { warned.remove(s.name()); continue; }
                int max = st.getMaxDamage();
                float left = (max - st.getDamage()) * 100f / max;
                if (left <= threshold.value) {
                    if (warned.add(s.name())) Notifier.push("Low durability", st.getName().getString() + "  " + Math.round(left) + "%", 0xFFFF6060);
                } else if (left > threshold.value + 10) warned.remove(s.name());
            }
        }
    }
}

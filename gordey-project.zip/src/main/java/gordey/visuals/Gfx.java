package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class Gfx {
    private Gfx() { }

    public static int alpha(int color, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (color & 0xFFFFFF); }

    public static int mulAlpha(int color, float f) {
        int a = (int) (((color >>> 24) & 0xFF) * f);
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 0xFF) + (((c2 >>> 24) & 0xFF) - ((c1 >>> 24) & 0xFF)) * t);
        int r = (int) (((c1 >> 16) & 0xFF) + (((c2 >> 16) & 0xFF) - ((c1 >> 16) & 0xFF)) * t);
        int g = (int) (((c1 >> 8) & 0xFF) + (((c2 >> 8) & 0xFF) - ((c1 >> 8) & 0xFF)) * t);
        int b = (int) ((c1 & 0xFF) + ((c2 & 0xFF) - (c1 & 0xFF)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static float easeOut(float t) { t = Math.max(0f, Math.min(1f, t)); return 1f - (1f - t) * (1f - t) * (1f - t); }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    /** Rounded rectangle built from horizontal strips. */
    public static void round(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { ctx.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void outline(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        ctx.fill(x + r, y, x + w - r, y + 1, color);
        ctx.fill(x + r, y + h - 1, x + w - r, y + h, color);
        ctx.fill(x, y + r, x + 1, y + h - r, color);
        ctx.fill(x + w - 1, y + r, x + w, y + h - r, color);
    }

    /** Pixel line using merged runs (cheap). */
    public static void line(DrawContext ctx, int x0, int y0, int x1, int y1, int color, int t) {
        int dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
        if (dx > 4000 || dy > 4000) return;
        if (dx == 0 && dy == 0) { ctx.fill(x0, y0, x0 + t, y0 + t, color); return; }
        if (dx >= dy) {
            if (x0 > x1) { int a = x0; x0 = x1; x1 = a; a = y0; y0 = y1; y1 = a; }
            int run = x0, cur = y0;
            for (int x = x0; x <= x1; x++) {
                int y = Math.round(y0 + (x - x0) * (float) (y1 - y0) / (x1 - x0));
                if (y != cur) { ctx.fill(run, cur, x, cur + t, color); run = x; cur = y; }
            }
            ctx.fill(run, cur, x1 + 1, cur + t, color);
        } else {
            if (y0 > y1) { int a = x0; x0 = x1; x1 = a; a = y0; y0 = y1; y1 = a; }
            int run = y0, cur = x0;
            for (int y = y0; y <= y1; y++) {
                int x = Math.round(x0 + (y - y0) * (float) (x1 - x0) / (y1 - y0));
                if (x != cur) { ctx.fill(cur, run, cur + t, y, color); run = y; cur = x; }
            }
            ctx.fill(cur, run, cur + t, y1 + 1, color);
        }
    }

    /** Fills a convex polygon with horizontal scanlines. */
    public static void fillPoly(DrawContext ctx, float[] xs, float[] ys, int n, int color) {
        float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]); }
        if (maxY - minY > 3000) return;
        for (int y = (int) Math.ceil(minY); y <= maxY; y++) {
            float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float yi = ys[i], yj = ys[j];
                if ((yi <= y && yj > y) || (yj <= y && yi > y)) {
                    float x = xs[i] + (y - yi) / (yj - yi) * (xs[j] - xs[i]);
                    lo = Math.min(lo, x); hi = Math.max(hi, x);
                }
            }
            if (lo <= hi) ctx.fill((int) lo, y, (int) hi + 1, y + 1, color);
        }
    }

    public static void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, true);
    }

    public static void textPlain(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer, s, x, y, color, false);
    }

    public static int width(String s) { return MinecraftClient.getInstance().textRenderer.getWidth(s); }

    public static void centered(DrawContext ctx, String s, int cx, int y, int color) {
        text(ctx, s, cx - width(s) / 2, y, color);
    }
}

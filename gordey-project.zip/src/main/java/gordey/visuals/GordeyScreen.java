package gordey.visuals;

import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class GordeyScreen extends Screen {
    private static final int PWMAX = 176, GAP = 14, ROW_H = 20, ROW_GAP = 3;
    private int PW = 176;
    private static final int BOOL_H = 17, MODE_H = 17, ACTION_H = 19, NUM_H = 25, COL_H = 60, BIND_H = 17;
    private static final Module.Category[] CATS = {Module.Category.VISUALS, Module.Category.OTHER, Module.Category.PLAYER};

    private final float[] scroll = new float[3], scrollTarget = new float[3], maxScroll = new float[3];
    private final int[][] panelRects = new int[3][4];
    private final boolean[] keyCur = new boolean[349], keyPrev = new boolean[349];

    private DrawContext ctx;
    private int mx, my;
    private boolean down, prevDown, prevRight, clicked, rclicked, started;
    private int clipX1, clipY1, clipX2, clipY2;
    private float dt, openAnim;
    private long lastNanos;

    private boolean searching;
    private final StringBuilder query = new StringBuilder();
    private Module listening;
    private Setting.Text editingText;
    private Object dragging;
    private int dragIdx;
    private HudModule dragHud;
    private int dragOffX, dragOffY;
    private String tooltip;
    private int searchX, searchY, searchW = 176, searchH = 18;

    public GordeyScreen() { super(Text.literal("Gordey Visuals")); }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return !searching && listening == null && editingText == null; }
    @Override public void removed() { ModuleManager.save(); }

    private boolean edge(int k) { return keyCur[k] && !keyPrev[k]; }

    private boolean hit(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h
                && mx >= clipX1 && mx < clipX2 && my >= clipY1 && my < clipY2;
    }

    private boolean overUi() {
        for (int[] r : panelRects) if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) return true;
        return mx >= searchX && mx < searchX + searchW && my >= searchY && my < searchY + searchH;
    }

    private boolean matches(Module m) {
        return query.length() == 0 || m.name.toLowerCase().contains(query.toString());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.ctx = context; this.mx = mouseX; this.my = mouseY;
        long now = System.nanoTime();
        dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        float speed = ModuleManager.iface.speed.asFloat();
        openAnim = Math.min(1f, openAnim + dt * 4f * speed);
        float ea = Gfx.easeOut(openAnim);

        long handle = client.getWindow().getHandle();
        down = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        for (int k = 32; k <= 348; k++) {
            keyPrev[k] = keyCur[k];
            keyCur[k] = Keys.valid(k) && GLFW.glfwGetKey(handle, k) == GLFW.GLFW_PRESS;
        }
        if (!started) {
            prevDown = down; prevRight = right;
            System.arraycopy(keyCur, 0, keyPrev, 0, keyCur.length);
            started = true;
        }
        clicked = down && !prevDown;
        rclicked = right && !prevRight;
        prevDown = down; prevRight = right;
        if (!down) { dragging = null; dragHud = null; }

        handleKeys();

        clipX1 = 0; clipY1 = 0; clipX2 = width; clipY2 = height;
        tooltip = null;
        int ac = Theme.accent(), ac2 = Theme.accent2();

        // backdrop
        ctx.fillGradient(0, 0, width, height, Gfx.alpha(0x000000, (int) (ModuleManager.iface.dim.value * ea)), Gfx.alpha(ac, (int) (45 * ea)));

        // layout
        int panelH = Math.min(310, height - 90);
        PW = Math.max(120, Math.min(PWMAX, (width - GAP * 2 - 24) / 3));
        int totalW = PW * 3 + GAP * 2;
        int left = (width - totalW) / 2;
        int top = (height - panelH) / 2 + 6 + Math.round((1f - ea) * 20);
        for (int i = 0; i < 3; i++) { panelRects[i][0] = left + i * (PW + GAP); panelRects[i][1] = top; panelRects[i][2] = PW; panelRects[i][3] = panelH; }
        searchW = Math.min(176, PW * 2); searchX = (width - searchW) / 2; searchY = top + panelH + 8;

        drawHudEditor();

        // logo above panels
        int ly = top - 22;
        int lx = (width - 124) / 2;
        Icons.drawTinted(ctx, Icons.G28, lx, ly - 6, 24, 24, ac & 0xFFFFFF);
        String hs = ModuleManager.iface.textStyle.get();
        TextFx.draw(ctx, "Gordey Visuals", lx + 30, ly + 4, 0xFFFFFFFF, hs.equals("Normal") ? "Gradient" : hs, ac, ac2);

        for (int i = 0; i < 3; i++) drawPanel(i, CATS[i], panelRects[i][0], panelRects[i][1], PW, panelH);

        drawSearch();
        String ver = "Gordey Visuals 1.0.0";
        String tip = "ЛКМ - вкл/выкл   ПКМ или ... - настройки   HUD можно перетаскивать";
        int verW = Gfx.width(ver), tipW = Gfx.width(tip);
        if (verW + tipW + 40 < width) {
            Gfx.textPlain(ctx, ver, 8, height - 14, 0xFF808090);
            Gfx.textPlain(ctx, tip, width - 8 - tipW, height - 14, 0xFF808090);
        } else if (tipW + 16 < width) {
            Gfx.textPlain(ctx, tip, (width - tipW) / 2, height - 14, 0xFF808090);
        }

        if (tooltip != null && dragging == null) {
            int tw = Gfx.width(tooltip) + 10;
            int tx = Math.min(mx + 10, width - tw - 4), ty = Math.min(my + 14, height - 20);
            Gfx.round(ctx, tx - 1, ty - 1, tw + 2, 18, 4, Gfx.alpha(ac, 110));
            Gfx.round(ctx, tx, ty, tw, 16, 3, 0xFA0C0C11);
            Gfx.textPlain(ctx, tooltip, tx + 5, ty + 4, 0xFFE0E0EA);
        }
    }

    private void handleKeys() {
        boolean ctrl = keyCur[341] || keyCur[345];
        if (listening != null) {
            for (int k = 32; k <= 348; k++) {
                if (!edge(k)) continue;
                if (k == 256) listening = null;
                else if (k == 259 || k == 261) { listening.key = -1; listening = null; ModuleManager.dirty = true; }
                else { listening.key = k; listening = null; ModuleManager.dirty = true; }
                break;
            }
            return;
        }
        if (editingText != null) {
            if (edge(256) || edge(257)) { editingText = null; ModuleManager.dirty = true; return; }
            boolean shift = keyCur[340] || keyCur[344];
            String v = editingText.value;
            if (edge(259) && !v.isEmpty()) v = v.substring(0, v.length() - 1);
            if (v.length() < editingText.max) {
                for (int k = 32; k <= 348; k++) {
                    if (!edge(k)) continue;
                    char c = 0;
                    if (k >= 65 && k <= 90) c = (char) (shift ? k : k + 32);
                    else if (k >= 48 && k <= 57) c = (char) k;
                    else if (k == 32) c = ' ';
                    else if (k == 47) c = '/';
                    else if (k == 45) c = shift ? '_' : '-';
                    else if (k == 46) c = '.';
                    else if (k == 44) c = ',';
                    if (c != 0) v += c;
                }
            }
            editingText.value = v;
            return;
        }
        if (ctrl && edge(70)) { searching = !searching; if (searching) query.setLength(0); return; }
        if (searching) {
            if (edge(256)) { searching = false; query.setLength(0); return; }
            if (edge(257)) { searching = false; return; }
            if (edge(259) && query.length() > 0) query.setLength(query.length() - 1);
            if (query.length() < 20) {
                for (int k = 65; k <= 90; k++) if (edge(k) && !ctrl) query.append((char) ('a' + k - 65));
                for (int k = 48; k <= 57; k++) if (edge(k) && !ctrl) query.append((char) k);
                if (edge(32)) query.append(' ');
            }
            return;
        }
        int ik = ModuleManager.iface.key;
        if (ik >= 0 && Keys.valid(ik) && edge(ik)) close();
    }

    private void drawHudEditor() {
        int ac = Theme.accent();
        HudModule hovered = null;
        for (Module m : ModuleManager.ALL) {
            if (!(m instanceof HudModule h) || !h.enabled || h.w <= 0) continue;
            int bx = h.left(), by = h.y;
            boolean hv = mx >= bx && mx < bx + h.w && my >= by && my < by + h.h && !overUi();
            if (hv) hovered = h;
            Gfx.outline(ctx, bx - 2, by - 2, h.w + 4, h.h + 4, 0, Gfx.alpha(ac, hv || dragHud == h ? 230 : 110));
            Gfx.textPlain(ctx, h.name, bx, by - 12 < 0 ? by + h.h + 4 : by - 12, Gfx.alpha(0xFFFFFF, hv ? 230 : 120));
        }
        if (clicked && hovered != null && dragHud == null) {
            dragHud = hovered;
            dragOffX = mx - hovered.left();
            dragOffY = my - hovered.y;
        }
        if (dragHud != null && down) {
            int nx = Math.max(0, Math.min(width - Math.max(8, dragHud.w), mx - dragOffX));
            int ny = Math.max(0, Math.min(height - Math.max(8, dragHud.h), my - dragOffY));
            dragHud.x = dragHud.left() == dragHud.x ? nx : nx + dragHud.w;
            dragHud.y = ny;
            ModuleManager.dirty = true;
        }
    }

    private void drawSearch() {
        int ac = Theme.accent();
        boolean hv = mx >= searchX && mx < searchX + searchW && my >= searchY && my < searchY + searchH;
        if (clicked && hv) { searching = true; query.setLength(0); }
        Gfx.round(ctx, searchX - 1, searchY - 1, searchW + 2, searchH + 2, 9, Gfx.alpha(ac, searching ? 200 : 60));
        Gfx.round(ctx, searchX, searchY, searchW, searchH, 8, 0xF0101015);
        String s;
        if (searching) s = "Поиск: " + query + (System.currentTimeMillis() / 500 % 2 == 0 ? "|" : "");
        else s = query.length() > 0 ? "Поиск: " + query : "Поиск: Ctrl + F";
        Gfx.centered(ctx, s, searchX + searchW / 2, searchY + 5, searching ? 0xFFFFFFFF : 0xFF9A9AA6);
    }

    private void drawPanel(int idx, Module.Category cat, int px, int py, int pw, int ph) {
        int ac = Theme.accent(), ac2 = Theme.accent2();
        Gfx.round(ctx, px - 1, py - 1, pw + 2, ph + 2, 9, Gfx.alpha(ac, 70));
        Gfx.round(ctx, px, py, pw, ph, 8, 0xF0101015);
        String hst = ModuleManager.iface.textStyle.get();
        TextFx.draw(ctx, cat.label, px + pw / 2 - TextFx.width(cat.label, hst) / 2, py + 9, 0xFFFFFFFF, hst, ac, ac2);
        int lw = pw - 24;
        for (int i = 0; i < lw; i += 2) ctx.fill(px + 12 + i, py + 22, px + 12 + Math.min(i + 2, lw), py + 23, Gfx.lerp(ac, ac2, i / (float) lw));

        int vx = px + 6, vy = py + 30, vw = pw - 12, vh = ph - 36;
        scroll[idx] += (scrollTarget[idx] - scroll[idx]) * Math.min(1f, dt * 16f);
        clipX1 = vx; clipY1 = vy; clipX2 = vx + vw; clipY2 = vy + vh;
        ctx.enableScissor(vx, vy, vx + vw, vy + vh);
        int y = vy - Math.round(scroll[idx]);
        int shown = 0;
        int rowW = vw - (maxScroll[idx] > 0 ? 5 : 0);
        List<Module> list = new ArrayList<>();
        for (Module m : ModuleManager.ALL) if (m.category == cat && matches(m)) list.add(m);
        list.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        for (Module m : list) {
            y += drawModule(m, vx, y, rowW);
            shown++;
        }
        if (shown == 0) Gfx.centered(ctx, "Ничего не найдено", px + pw / 2, vy + 10, 0xFF808090);
        ctx.disableScissor();
        clipX1 = 0; clipY1 = 0; clipX2 = width; clipY2 = height;

        int total = y + Math.round(scroll[idx]) - vy;
        maxScroll[idx] = Math.max(0, total - vh);
        scrollTarget[idx] = Math.max(0, Math.min(maxScroll[idx], scrollTarget[idx]));
        if (maxScroll[idx] > 0) {
            int bh = Math.max(16, Math.round(vh * (vh / (float) total)));
            int by = vy + Math.round((vh - bh) * (scroll[idx] / maxScroll[idx]));
            Gfx.round(ctx, px + pw - 6, by, 2, bh, 1, Gfx.alpha(ac, 190));
        }
    }

    private int drawModule(Module m, int x, int y, int w) {
        int ac = Theme.accent();
        boolean on = m.enabled || m.alwaysOn();
        m.enableAnim += ((on ? 1f : 0f) - m.enableAnim) * Math.min(1f, dt * 14f);
        if (Math.abs(m.enableAnim - (on ? 1f : 0f)) < 0.01f) m.enableAnim = on ? 1f : 0f;
        float target = m.expanded ? 1f : 0f;
        m.expandAnim += (target - m.expandAnim) * Math.min(1f, dt * 12f);
        if (Math.abs(m.expandAnim - target) < 0.01f) m.expandAnim = target;

        boolean hover = hit(x, y, w, ROW_H);
        boolean dots = hit(x + w - 24, y, 24, ROW_H);
        Gfx.round(ctx, x, y, w, ROW_H, 4, hover ? 0xFF1E1E27 : 0xFF17171E);
        if (m.enableAnim > 0.01f) {
            Gfx.round(ctx, x, y, w, ROW_H, 4, Gfx.alpha(ac, (int) (58 * m.enableAnim)));
            ctx.fill(x, y + 4, x + 2, y + ROW_H - 4, Gfx.alpha(ac, (int) (255 * m.enableAnim)));
        }
        Gfx.text(ctx, m.name, x + 9, y + 6, Gfx.lerp(0xFF9A9AA6, 0xFFFFFFFF, m.enableAnim));
        Gfx.textPlain(ctx, "...", x + w - 18, y + 5, m.expanded || dots ? ac : 0xFF7A7A86);
        if (hover) tooltip = m.description;

        if (clicked && hover) {
            if (dots || m.alwaysOn()) m.expanded = !m.expanded;
            else m.toggle();
        } else if (rclicked && hover) m.expanded = !m.expanded;

        int used = ROW_H + ROW_GAP;
        if (m.expandAnim > 0f) {
            int total = settingsHeight(m);
            int vis = Math.round(total * Gfx.ease(m.expandAnim));
            if (vis > 0) {
                boolean act = m.expandAnim >= 0.98f;
                int sy = y + ROW_H + 2;
                ctx.enableScissor(Math.max(x, clipX1), Math.max(sy, clipY1), Math.min(x + w, clipX2), Math.min(sy + vis, clipY2));
                Gfx.round(ctx, x + 3, sy, w - 6, total, 4, 0xFF101016);
                int cy = sy + 3;
                for (Setting s : m.allSettings()) {
                    if (!s.visible.getAsBoolean()) continue;
                    cy += drawSetting(s, x + 3, cy, w - 6, act);
                }
                drawBind(m, x + 3, cy, w - 6, act);
                ctx.disableScissor();
                used += vis + 4;
            }
        }
        return used;
    }

    private int settingsHeight(Module m) {
        int h = 6 + BIND_H;
        for (Setting s : m.allSettings()) {
            if (!s.visible.getAsBoolean()) continue;
            h += heightOf(s);
        }
        return h;
    }

    private int heightOf(Setting s) {
        if (s instanceof Setting.Num) return NUM_H;
        if (s instanceof Setting.Col) return COL_H;
        if (s instanceof Setting.Action) return ACTION_H;
        if (s instanceof Setting.Mode) return MODE_H;
        return BOOL_H;
    }

    private int drawSetting(Setting s, int x, int y, int w, boolean act) {
        int ac = Theme.accent();
        if (s instanceof Setting.Bool b) {
            boolean hv = act && hit(x, y, w, BOOL_H);
            if (hv) Gfx.round(ctx, x + 1, y, w - 2, BOOL_H, 3, 0xFF181820);
            Gfx.textPlain(ctx, b.name, x + 5, y + 4, 0xFFC8C8D2);
            int sx = x + w - 25;
            Gfx.round(ctx, sx, y + 4, 19, 9, 4, b.value ? ac : 0xFF34343E);
            Gfx.round(ctx, b.value ? sx + 11 : sx + 1, y + 5, 7, 7, 3, 0xFFFFFFFF);
            if (hv && clicked) { b.value = !b.value; ModuleManager.dirty = true; }
            return BOOL_H;
        }
        if (s instanceof Setting.Num n) {
            Gfx.textPlain(ctx, n.name, x + 5, y + 3, 0xFFC8C8D2);
            String v = n.display();
            Gfx.textPlain(ctx, v, x + w - 5 - Gfx.width(v), y + 3, 0xFFFFFFFF);
            int tx = x + 5, tw = w - 10, ty = y + 16;
            float p = (float) ((n.value - n.min) / (n.max - n.min));
            Gfx.round(ctx, tx, ty, tw, 4, 2, 0xFF2A2A33);
            Gfx.round(ctx, tx, ty, Math.max(4, Math.round(tw * p)), 4, 2, ac);
            Gfx.round(ctx, tx + Math.round((tw - 6) * p), ty - 2, 6, 8, 3, 0xFFFFFFFF);
            if (act && clicked && hit(x, y + 10, w, 14)) dragging = n;
            if (dragging == n) {
                double q = Math.max(0, Math.min(1, (mx - tx) / (double) tw));
                n.set(n.min + q * (n.max - n.min));
                ModuleManager.dirty = true;
            }
            return NUM_H;
        }
        if (s instanceof Setting.Mode md) {
            boolean hv = act && hit(x, y, w, MODE_H);
            if (hv) Gfx.round(ctx, x + 1, y, w - 2, MODE_H, 3, 0xFF181820);
            Gfx.textPlain(ctx, md.name, x + 5, y + 4, 0xFFC8C8D2);
            String v = "< " + md.get() + " >";
            Gfx.textPlain(ctx, v, x + w - 5 - Gfx.width(v), y + 4, ac);
            if (hv && clicked) { md.next(1); ModuleManager.dirty = true; }
            if (hv && rclicked) { md.next(-1); ModuleManager.dirty = true; }
            return MODE_H;
        }
        if (s instanceof Setting.Col c) {
            Gfx.textPlain(ctx, c.name, x + 5, y + 3, 0xFFC8C8D2);
            Gfx.round(ctx, x + w - 25, y + 3, 20, 9, 3, 0xFF000000 | c.rgb());
            int bx = x + 5, bw = w - 10;
            for (int i = 0; i < 3; i++) {
                int by = y + 18 + i * 14;
                for (int px = 0; px < bw; px += 2) {
                    float t = px / (float) bw;
                    int col = i == 0 ? java.awt.Color.HSBtoRGB(t, 1f, 1f)
                            : i == 1 ? java.awt.Color.HSBtoRGB(c.h, t, 1f)
                            : java.awt.Color.HSBtoRGB(c.h, c.s, t);
                    ctx.fill(bx + px, by, bx + Math.min(px + 2, bw), by + 8, 0xFF000000 | (col & 0xFFFFFF));
                }
                float val = i == 0 ? c.h : i == 1 ? c.s : c.b;
                int kx = bx + Math.round((bw - 2) * val);
                ctx.fill(kx - 1, by - 2, kx + 2, by + 10, 0xFFFFFFFF);
                if (act && clicked && hit(bx - 2, by - 3, bw + 4, 14)) { dragging = c; dragIdx = i; }
                if (dragging == c && dragIdx == i) {
                    float t = Math.max(0f, Math.min(1f, (mx - bx) / (float) bw));
                    if (i == 0) c.h = t; else if (i == 1) c.s = t; else c.b = t;
                    ModuleManager.dirty = true;
                }
            }
            return COL_H;
        }
        if (s instanceof Setting.Text t) {
            boolean hv = act && hit(x, y, w, BOOL_H);
            boolean ed = editingText == t;
            if (hv || ed) Gfx.round(ctx, x + 1, y, w - 2, BOOL_H, 3, ed ? Gfx.alpha(ac, 60) : 0xFF181820);
            Gfx.textPlain(ctx, t.name, x + 5, y + 4, 0xFFC8C8D2);
            String shown = t.value.isEmpty() && !ed ? "(empty)" : t.value + (ed && System.currentTimeMillis() / 500 % 2 == 0 ? "|" : "");
            int maxW = w / 2 - 6;
            while (Gfx.width(shown) > maxW && shown.length() > 1) shown = shown.substring(1);
            Gfx.textPlain(ctx, shown, x + w - 5 - Gfx.width(shown), y + 4, ed ? 0xFFFFFFFF : ac);
            if (act && clicked) editingText = hv ? t : (ed ? null : editingText);
            return BOOL_H;
        }
        if (s instanceof Setting.Action a) {
            boolean hv = act && hit(x, y, w, ACTION_H);
            Gfx.round(ctx, x + 4, y + 1, w - 8, ACTION_H - 3, 4, Gfx.alpha(ac, hv ? 230 : 140));
            Gfx.centered(ctx, a.name, x + w / 2, y + 5, 0xFFFFFFFF);
            if (hv && clicked) a.run.run();
            return ACTION_H;
        }
        return 0;
    }

    private void drawBind(Module m, int x, int y, int w, boolean act) {
        boolean hv = act && hit(x, y, w, BIND_H);
        if (hv) Gfx.round(ctx, x + 1, y, w - 2, BIND_H, 3, 0xFF181820);
        Gfx.textPlain(ctx, "Bind", x + 5, y + 4, 0xFFC8C8D2);
        String v = listening == m ? "..." : "[" + Keys.name(m.key) + "]";
        Gfx.textPlain(ctx, v, x + w - 5 - Gfx.width(v), y + 4, listening == m ? 0xFFFFFFFF : Theme.accent());
        if (hv && clicked) listening = m;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (int i = 0; i < 3; i++) {
            int[] r = panelRects[i];
            if (mouseX >= r[0] && mouseX < r[0] + r[2] && mouseY >= r[1] && mouseY < r[1] + r[3]) {
                scrollTarget[i] = Math.max(0, Math.min(maxScroll[i], scrollTarget[i] - (float) verticalAmount * 28f));
            }
        }
        return true;
    }
}

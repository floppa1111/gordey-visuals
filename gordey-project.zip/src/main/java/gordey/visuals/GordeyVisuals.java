package gordey.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;

public class GordeyVisuals implements ClientModInitializer {
    @Override
    @SuppressWarnings("deprecation")
    public void onInitializeClient() {
        ModuleManager.init();
        Player.register();
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world.isClient() && entity instanceof LivingEntity le) Stats.onAttack(le);
            return ActionResult.PASS;
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> renderHud(ctx));
        ClientTickEvents.END_CLIENT_TICK.register(ModuleManager::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> ModuleManager.shutdown());
    }

    private static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        Stats.pollMouse(mc);
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        for (int pass = 0; pass < 2; pass++) {
            for (Module m : ModuleManager.ALL) {
                if (m instanceof HudModule h && h.enabled && h.backdrop == (pass == 0)) {
                    h.layout(sw, sh);
                    h.draw(ctx, mc);
                }
            }
        }
        Player.drawHotbarLocks(ctx, mc, sw, sh);
        Notifier.render(ctx, sw, sh);
    }
}

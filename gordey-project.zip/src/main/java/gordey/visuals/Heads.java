package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class Heads {
    private Heads() { }

    /** Draws a player's face (skin head). For non-players draws a letter badge. */
    public static void draw(DrawContext ctx, MinecraftClient mc, LivingEntity e, int x, int y, int size, int accent) {
        if (e instanceof PlayerEntity p && mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (entry != null) {
                PlayerSkinDrawer.draw(ctx, entry.getSkinTextures(), x, y, size);
                return;
            }
        }
        ctx.fill(x, y, x + size, y + size, Gfx.alpha(accent, 90));
        try {
            Identifier id = Registries.ENTITY_TYPE.getId(e.getType());
            Item egg = Registries.ITEM.get(Identifier.of(id.getNamespace(), id.getPath() + "_spawn_egg"));
            if (egg != Items.AIR) {
                ctx.drawItem(new ItemStack(egg), x + (size - 16) / 2, y + (size - 16) / 2);
                return;
            }
        } catch (Throwable ignored) { }
        String s = e.getName().getString();
        String c = s.isEmpty() ? "?" : s.substring(0, 1).toUpperCase();
        Gfx.centered(ctx, c, x + size / 2, y + size / 2 - 4, 0xFFFFFFFF);
    }
}

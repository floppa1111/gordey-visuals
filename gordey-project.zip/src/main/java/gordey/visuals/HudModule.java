package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class HudModule extends Module {
    public static final int UNSET = Integer.MIN_VALUE;

    public int x = UNSET, y = UNSET, w, h;
    protected boolean anchorRight = false;
    public boolean backdrop = false;

    public final Setting.Bool useTheme = new Setting.Bool("Theme color", true);
    public final Setting.Col color = new Setting.Col("Color", 0.08f, 1f, 1f);
    public final Setting.Num opacity = new Setting.Num("Opacity", 170, 0, 255, 5);
    public final Setting.Num rounding = new Setting.Num("Rounding", 0, 0, 6, 1);
    public final Setting.Mode effect = new Setting.Mode("Effect", 1, "None", "Gradient", "Pulse", "Glow", "Outline", "Rainbow");
    public final Setting.Mode textStyle = new Setting.Mode("Text style", 0, "Global", "Normal", "Gradient", "Glow", "Spaced", "Rainbow", "Outline");
    protected final List<Setting> style = new ArrayList<>(List.of(useTheme, color, opacity, rounding, effect, textStyle));

    protected HudModule(String name, String description) {
        super(name, description, Category.VISUALS);
        color.visible = () -> !useTheme.value;
    }

    @Override public List<Setting> allSettings() {
        List<Setting> all = new ArrayList<>(settings);
        all.addAll(style);
        return all;
    }

    public abstract void draw(DrawContext ctx, MinecraftClient mc);

    protected int defaultX(int sw) { return 6; }
    protected int defaultY(int sh) { return 6; }

    protected String styleName() {
        if (textStyle.is("Global")) return ModuleManager.iface != null ? ModuleManager.iface.textStyle.get() : "Normal";
        return textStyle.get();
    }

    protected int fx(DrawContext ctx, String s, int x, int y, int color) {
        return TextFx.draw(ctx, s, x, y, color, styleName(), accent(), accent2());
    }

    protected int fxWidth(String s) { return TextFx.width(s, styleName()); }

    public void resetPosition() { x = UNSET; y = UNSET; }

    public void layout(int sw, int sh) {
        if (x == UNSET) x = defaultX(sw);
        if (y == UNSET) y = defaultY(sh);
    }

    public int left() { return anchorRight ? x - w : x; }

    public int accent() {
        if (effect.is("Rainbow")) return 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 5000L) / 5000f, 0.7f, 1f);
        return useTheme.value ? Theme.accent() : 0xFF000000 | color.rgb();
    }

    public int accent2() { return Theme.shift(accent(), 0.09f); }

    protected int bgColor() { return (opacity.asInt() << 24) | 0x0C0C11; }

    protected void panel(DrawContext ctx, int px, int py, int pw, int ph) {
        int ac = accent(), ac2 = accent2();
        int r = rounding.asInt();
        long t = System.currentTimeMillis();

        if (effect.is("Glow")) {
            for (int i = 5; i >= 1; i--) Gfx.round(ctx, px - i, py - i, pw + i * 2, ph + i * 2, r + i, Gfx.alpha(ac, 10 + (6 - i) * 5));
        }
        Gfx.round(ctx, px, py, pw, ph, r, bgColor());

        if (effect.is("Gradient")) {
            int in = r > 0 ? r / 2 + 1 : 0;
            ctx.fillGradient(px + in, py + in, px + pw - in, py + ph - in, Gfx.alpha(ac, 75), Gfx.alpha(ac2, 0));
        }
        if (effect.is("Pulse")) {
            int a = 60 + (int) (150 * (0.5 + 0.5 * Math.sin(t / 380.0)));
            Gfx.outline(ctx, px, py, pw, ph, r, Gfx.alpha(ac, a));
        }
        if (effect.is("Outline") || effect.is("Glow")) Gfx.outline(ctx, px, py, pw, ph, r, Gfx.alpha(ac, 210));
        if (r == 0) ctx.fill(px, py, px + 2, py + ph, ac);
    }
}

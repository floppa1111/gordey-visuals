package gordey.visuals;

public final class Keys {
    private Keys() { }

    private static final int[][] RANGES = {{32, 32}, {39, 39}, {44, 57}, {59, 59}, {61, 61}, {65, 93}, {96, 96},
            {256, 269}, {280, 284}, {290, 314}, {320, 348}};

    public static boolean valid(int k) {
        for (int[] r : RANGES) if (k >= r[0] && k <= r[1]) return true;
        return false;
    }

    public static String name(int k) {
        if (k < 0) return "None";
        if ((k >= 65 && k <= 90) || (k >= 48 && k <= 57)) return String.valueOf((char) k);
        if (k >= 290 && k <= 314) return "F" + (k - 289);
        if (k >= 320 && k <= 329) return "Num" + (k - 320);
        switch (k) {
            case 32: return "Space";
            case 256: return "Esc";
            case 257: return "Enter";
            case 258: return "Tab";
            case 259: return "Backspace";
            case 260: return "Insert";
            case 261: return "Delete";
            case 262: return "Right";
            case 263: return "Left";
            case 264: return "Down";
            case 265: return "Up";
            case 266: return "PgUp";
            case 267: return "PgDn";
            case 268: return "Home";
            case 269: return "End";
            case 340: return "LShift";
            case 341: return "LCtrl";
            case 342: return "LAlt";
            case 344: return "RShift";
            case 345: return "RCtrl";
            case 346: return "RAlt";
            default: return "Key" + k;
        }
    }
}

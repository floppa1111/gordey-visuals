package gordey.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Media {
    private Media() { }

    // ================================================================ TRACKER
    public static final class Tracker {
        private Tracker() { }

        public static volatile boolean available = true, hasMedia, playing;
        public static volatile String title = "", artist = "";
        public static volatile double basePos, dur;
        public static volatile long updMs;
        public static volatile String[] lyrics = new String[0];
        public static volatile double[] lyricTimes = new double[0];
        public static volatile String lyricsState = "idle"; // idle / loading / ready / none

        private static volatile boolean active;
        private static volatile Process proc;
        private static String lyricKey = "";
        private static boolean hookAdded;
        private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

        // Reads the current media session (Spotify, browser, etc.) through Windows' media controls.
        private static final String SCRIPT = String.join("\n",
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8",
                "Add-Type -AssemblyName System.Runtime.WindowsRuntime",
                "$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]",
                "function Await($op, $type) { $t = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op)); $t.Wait(-1) | Out-Null; $t.Result }",
                "[void][Windows.Media.Control.GlobalSystemMediaTransportSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]",
                "[void][Windows.Media.Control.GlobalSystemMediaTransportSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]",
                "$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportSessionManager])",
                "while ($true) {",
                "  try {",
                "    $s = $mgr.GetCurrentSession()",
                "    if ($s -ne $null) {",
                "      $p = Await ($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportSessionMediaProperties])",
                "      $tl = $s.GetTimelineProperties(); $pb = $s.GetPlaybackInfo()",
                "      $o = [ordered]@{ title = [string]$p.Title; artist = [string]$p.Artist; status = [string]$pb.PlaybackStatus; pos = $tl.Position.TotalSeconds; dur = $tl.EndTime.TotalSeconds; upd = $tl.LastUpdatedTime.ToUnixTimeMilliseconds() }",
                "      $o | ConvertTo-Json -Compress",
                "    } else { '{\"none\":true}' }",
                "  } catch { '{\"none\":true}' }",
                "  [Console]::Out.Flush()",
                "  Start-Sleep -Milliseconds 700",
                "}");

        public static synchronized void setActive(boolean on) {
            if (on == active) return;
            active = on;
            if (on) start(); else stop();
        }

        private static void start() {
            if (!System.getProperty("os.name", "").toLowerCase().contains("win")) { available = false; return; }
            available = true;
            if (!hookAdded) {
                hookAdded = true;
                Runtime.getRuntime().addShutdownHook(new Thread(() -> { Process p = proc; if (p != null) p.destroyForcibly(); }));
            }
            Thread t = new Thread(Tracker::loop, "gordey-media");
            t.setDaemon(true);
            t.start();
        }

        private static void stop() {
            Process p = proc;
            if (p != null) p.destroy();
            hasMedia = false;
            playing = false;
        }

        private static void loop() {
            String encoded = Base64.getEncoder().encodeToString(SCRIPT.getBytes(StandardCharsets.UTF_16LE));
            int fails = 0;
            while (active && fails < 5) {
                boolean got = false;
                try {
                    ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
                            "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-EncodedCommand", encoded);
                    pb.redirectErrorStream(true);
                    Process p = pb.start();
                    proc = p;
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while (active && (line = br.readLine()) != null) {
                            line = line.trim();
                            if (line.startsWith("{")) { got = true; handle(line); }
                        }
                    }
                    p.destroy();
                } catch (Exception ignored) { }
                if (!got) fails++;
                if (active) {
                    try { Thread.sleep(2000); } catch (InterruptedException ignored) { }
                }
            }
            if (fails >= 5) available = false;
        }

        private static void handle(String line) {
            try {
                JsonObject o = JsonParser.parseString(line).getAsJsonObject();
                if (o.has("none")) { hasMedia = false; playing = false; return; }
                String t = o.get("title").getAsString(), a = o.get("artist").getAsString();
                playing = "Playing".equals(o.get("status").getAsString());
                basePos = o.get("pos").getAsDouble();
                dur = o.get("dur").getAsDouble();
                updMs = o.get("upd").getAsLong();
                title = t; artist = a;
                hasMedia = !t.isEmpty();
                String key = a + "\u0000" + t;
                if (hasMedia && !key.equals(lyricKey)) {
                    lyricKey = key;
                    lyrics = new String[0];
                    lyricTimes = new double[0];
                    fetchLyrics(t, a, dur, key);
                }
            } catch (Exception ignored) { }
        }

        public static double position() {
            if (!hasMedia) return 0;
            double p = basePos;
            if (playing) p += (System.currentTimeMillis() - updMs) / 1000.0;
            if (dur > 0) p = Math.min(p, dur);
            return Math.max(0, p);
        }

        // ---------------------------------------------------------- lyrics (synced, from the public LRCLIB service)
        private static void fetchLyrics(String t, String a, double d, String key) {
            lyricsState = "loading";
            Thread th = new Thread(() -> {
                try {
                    String lrc = lrcGet(t, a, d);
                    if (lrc == null) lrc = lrcGet(clean(t), a, d);
                    if (lrc == null) lrc = lrcSearch((a + " " + clean(t)).trim());
                    if (!key.equals(lyricKey)) return;
                    if (lrc == null) { lyricsState = "none"; return; }
                    parseLrc(lrc);
                    lyricsState = lyrics.length > 0 ? "ready" : "none";
                } catch (Exception e) {
                    if (key.equals(lyricKey)) lyricsState = "none";
                }
            }, "gordey-lyrics");
            th.setDaemon(true);
            th.start();
        }

        private static String clean(String s) {
            String r = s.replaceAll("\\(.*?\\)|\\[.*?\\]", "");
            int i = r.indexOf(" - ");
            if (i > 0) r = r.substring(0, i);
            return r.trim();
        }

        private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

        private static String http(String url) throws Exception {
            HttpRequest rq = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(8))
                    .header("User-Agent", "GordeyVisuals/1.0").GET().build();
            HttpResponse<String> rs = HTTP.send(rq, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            return rs.statusCode() == 200 ? rs.body() : null;
        }

        private static String synced(JsonObject o) {
            if (o == null || !o.has("syncedLyrics")) return null;
            JsonElement e = o.get("syncedLyrics");
            return e.isJsonNull() ? null : e.getAsString();
        }

        private static String lrcGet(String t, String a, double d) {
            try {
                String url = "https://lrclib.net/api/get?track_name=" + enc(t) + "&artist_name=" + enc(a)
                        + (d > 0 ? "&duration=" + Math.round(d) : "");
                String body = http(url);
                return body == null ? null : synced(JsonParser.parseString(body).getAsJsonObject());
            } catch (Exception e) { return null; }
        }

        private static String lrcSearch(String q) {
            try {
                String body = http("https://lrclib.net/api/search?q=" + enc(q));
                if (body == null) return null;
                JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
                for (JsonElement e : arr) {
                    String s = synced(e.getAsJsonObject());
                    if (s != null && !s.isBlank()) return s;
                }
            } catch (Exception ignored) { }
            return null;
        }

        private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?\\]");

        private static void parseLrc(String lrc) {
            List<double[]> times = new ArrayList<>();
            List<String> texts = new ArrayList<>();
            for (String line : lrc.split("\\r?\\n")) {
                Matcher m = STAMP.matcher(line);
                List<Double> stamps = new ArrayList<>();
                int end = 0;
                while (m.find() && m.start() == end) {
                    double sec = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
                    if (m.group(3) != null) sec += Double.parseDouble("0." + m.group(3));
                    stamps.add(sec);
                    end = m.end();
                }
                if (stamps.isEmpty()) continue;
                String text = line.substring(end).trim();
                for (double s : stamps) { times.add(new double[]{s}); texts.add(text); }
            }
            Integer[] idx = new Integer[times.size()];
            for (int i = 0; i < idx.length; i++) idx[i] = i;
            java.util.Arrays.sort(idx, (x, y) -> Double.compare(times.get(x)[0], times.get(y)[0]));
            String[] ly = new String[idx.length];
            double[] lt = new double[idx.length];
            for (int i = 0; i < idx.length; i++) { ly[i] = texts.get(idx[i]); lt[i] = times.get(idx[i])[0]; }
            lyricTimes = lt;
            lyrics = ly;
        }
    }

    static String mmss(double sec) {
        int s = (int) Math.max(0, sec);
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }

    static void marquee(DrawContext ctx, TextRenderer tr, String text, int x, int y, int maxW, int color) {
        int tw = tr.getWidth(text);
        if (tw <= maxW) { ctx.drawText(tr, text, x, y, color, true); return; }
        ctx.enableScissor(x, y - 1, x + maxW, y + 10);
        int off = (int) ((System.currentTimeMillis() / 30) % (tw + 24));
        ctx.drawText(tr, text, x - off, y, color, true);
        ctx.drawText(tr, text, x - off + tw + 24, y, color, true);
        ctx.disableScissor();
    }

    // ================================================================ NOW PLAYING
    public static final class NowPlayingMod extends HudModule {
        final Setting.Num width = add(new Setting.Num("Width", 210, 150, 320, 10));
        final Setting.Bool progress = add(new Setting.Bool("Progress bar", true));
        final Setting.Bool equalizer = add(new Setting.Bool("Equalizer", true));
        final Setting.Bool times = add(new Setting.Bool("Time", true));

        public NowPlayingMod() { super("NowPlaying", "Shows the music playing on your PC (Windows)."); }
        @Override protected int defaultX(int sw) { return sw / 2 - 105; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean editing = mc.currentScreen instanceof GordeyScreen;
            boolean has = Tracker.hasMedia;
            if (!Tracker.available) {
                if (!editing) { w = 0; h = 0; return; }
            } else if (!has && !editing) { w = 0; h = 0; return; }

            String title = has ? Tracker.title : (Tracker.available ? "Nothing playing" : "Windows only");
            String artist = has ? Tracker.artist : "Start music in any player";
            int pad = 6, cw = width.asInt();
            int ch = pad * 2 + 22 + (progress.value ? 9 : 0);
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            int ac = accent(), ac2 = accent2();

            int ex = px + pad + 2, ey = py + pad;
            int textX = ex;
            if (equalizer.value) {
                long t = System.currentTimeMillis();
                for (int i = 0; i < 4; i++) {
                    int bh = Tracker.playing ? 4 + (int) (14 * (0.5 + 0.5 * Math.sin(t / (110.0 + i * 37) + i * 1.7))) : 3;
                    ctx.fill(ex + i * 4, ey + 22 - bh, ex + i * 4 + 3, ey + 22, Gfx.lerp(ac, ac2, i / 3f));
                }
                textX = ex + 20;
            }
            int tw = px + cw - pad - textX;
            marquee(ctx, tr, title, textX, ey + 2, tw, 0xFFFFFFFF);
            ctx.drawText(tr, tr.trimToWidth(artist, tw), textX, ey + 13, 0xFFA8A8B3, false);

            if (progress.value) {
                double pos = Tracker.position(), dur = Tracker.dur;
                float f = dur > 0 ? (float) Math.min(1.0, pos / dur) : 0f;
                int bx = px + pad + 2, bw = cw - pad * 2 - 4, by = py + ch - pad - 2;
                if (times.value && dur > 0) {
                    String a = mmss(pos), b = mmss(dur);
                    ctx.drawText(tr, a, bx, by - 9, 0xFF8E8E9A, false);
                    ctx.drawText(tr, b, bx + bw - tr.getWidth(b), by - 9, 0xFF8E8E9A, false);
                }
                ctx.fill(bx, by, bx + bw, by + 2, 0xFF2A2A33);
                int fw = Math.round(bw * f);
                for (int i = 0; i < fw; i += 2) ctx.fill(bx + i, by, bx + Math.min(i + 2, fw), by + 2, Gfx.lerp(ac, ac2, i / (float) Math.max(1, bw)));
                ctx.fill(bx + fw - 1, by - 1, bx + fw + 2, by + 3, 0xFFFFFFFF);
            }
        }
    }

    // ================================================================ LYRICS
    public static final class LyricsMod extends HudModule {
        final Setting.Mode lines = add(new Setting.Mode("Lines", 1, "1", "3", "5"));
        final Setting.Num width = add(new Setting.Num("Width", 300, 200, 460, 10));
        final Setting.Num offset = add(new Setting.Num("Sync offset (s)", 0, -4, 4, 0.1));
        final Setting.Bool karaoke = add(new Setting.Bool("Karaoke highlight", true));
        final Setting.Bool showStatus = add(new Setting.Bool("Show status messages", false));

        public LyricsMod() { super("Lyrics", "Synced lyrics of the song you are listening to."); }
        @Override protected int defaultX(int sw) { return sw / 2 - 150; }
        @Override protected int defaultY(int sh) { return sh / 2 - 90; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean editing = mc.currentScreen instanceof GordeyScreen;
            String[] ly = Tracker.lyrics;
            double[] lt = Tracker.lyricTimes;
            int n = 1 + 2 * lines.index;
            int cw = width.asInt(), ch = n * 13 + 12;

            String[] show = new String[n];
            int cur = -1;
            boolean real = Tracker.hasMedia && ly.length > 0;
            double pos = Tracker.position() + offset.value;

            if (real) {
                for (int i = 0; i < ly.length; i++) { if (lt[i] <= pos) cur = i; else break; }
                for (int k = 0; k < n; k++) {
                    int idx = cur + (k - n / 2);
                    show[k] = (cur == -1 && k == n / 2) ? "..." : (idx >= 0 && idx < ly.length ? (ly[idx].isEmpty() ? "..." : ly[idx]) : "");
                }
            } else {
                String msg = null;
                if ("loading".equals(Tracker.lyricsState)) msg = "Loading lyrics...";
                else if ("none".equals(Tracker.lyricsState)) msg = "No synced lyrics found";
                if (editing && msg == null) msg = "Lyrics will appear here";
                if (msg == null || (!showStatus.value && !editing)) { w = 0; h = 0; return; }
                for (int k = 0; k < n; k++) show[k] = k == n / 2 ? msg : "";
            }

            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            int ac = accent();
            for (int k = 0; k < n; k++) {
                String text = tr.trimToWidth(show[k], cw - 16);
                if (text.isEmpty()) continue;
                int dist = Math.abs(k - n / 2);
                int ly0 = py + 6 + k * 13;
                int tw = tr.getWidth(text), x0 = px + (cw - tw) / 2;
                if (dist == 0) {
                    ctx.drawText(tr, text, x0, ly0, 0xFFFFFFFF, true);
                    if (real && karaoke.value && cur >= 0) {
                        double next = cur + 1 < lt.length ? lt[cur + 1] : lt[cur] + 4.0;
                        float f = (float) Math.max(0.0, Math.min(1.0, (pos - lt[cur]) / Math.max(0.2, next - lt[cur])));
                        ctx.enableScissor(x0, ly0 - 1, x0 + Math.round(tw * f), ly0 + 10);
                        ctx.drawText(tr, text, x0, ly0, ac, true);
                        ctx.disableScissor();
                    }
                } else {
                    ctx.drawText(tr, text, x0, ly0, Gfx.alpha(0xB4B4BE, Math.max(40, 190 - dist * 60)), false);
                }
            }
        }
    }
}

package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class Mods {
    private Mods() { }

    // =================================================================== VISUALS

    public static final class WatermarkMod extends HudModule {
        final Setting.Bool showFps = add(new Setting.Bool("FPS", true));
        final Setting.Bool showPing = add(new Setting.Bool("Ping", true));
        final Setting.Bool showCoords = add(new Setting.Bool("Coords", true));
        final Setting.Bool showBps = add(new Setting.Bool("Bps", true));
        final Setting.Bool showTime = add(new Setting.Bool("Time", false));
        final Setting.Mode logo = add(new Setting.Mode("Logo", 0, "Tinted", "Original", "Letter"));

        public WatermarkMod() {
            super("Watermark", "Square info panel with the G badge.");
            enabled = true;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<String[]> rows = new ArrayList<>();
            if (showFps.value) rows.add(new String[]{"FPS", String.valueOf(mc.getCurrentFps())});
            if (showPing.value) {
                int ping = 0;
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                    if (e != null) ping = e.getLatency();
                }
                rows.add(new String[]{"Ping", ping + " ms"});
            }
            if (showCoords.value) rows.add(new String[]{"XYZ", Player.StreamerModeMod.coords() ? "hidden" : mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ()});
            if (showBps.value) rows.add(new String[]{"Bps", String.format(Locale.ROOT, "%.1f", Stats.bps)});
            if (showTime.value) rows.add(new String[]{"Time", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))});

            String title = "Gordey Visuals";
            int pad = 5, badge = 16, rowH = 11;
            int cw = fxWidth(title) + badge + pad * 3 + 4;
            for (String[] r : rows) cw = Math.max(cw, tr.getWidth(r[0]) + tr.getWidth(r[1]) + pad * 2 + 18);
            int ch = pad + badge + (rows.isEmpty() ? 0 : 4) + rows.size() * rowH + pad;
            w = cw; h = ch;
            int px = left(), py = y;

            panel(ctx, px, py, cw, ch);
            int ac = accent(), ac2 = accent2();
            int bx = px + pad + 2, by = py + pad;
            if (logo.is("Letter")) {
                ctx.fillGradient(bx, by, bx + badge, by + badge, ac, ac2);
                ctx.drawText(tr, "G", bx + (badge - tr.getWidth("G")) / 2 + 1, by + 4, 0xFFFFFFFF, true);
            } else {
                Icons.drawTinted(ctx, Icons.G16, bx, by, badge, badge, logo.is("Original") ? 0xFF8C14 : (ac & 0xFFFFFF));
            }
            fx(ctx, title, bx + badge + 5, by + 4, 0xFFFFFFFF);
            int ry = by + badge + 4;
            for (String[] r : rows) {
                ctx.drawText(tr, r[0], px + pad + 2, ry, 0xFFA8A8B3, false);
                ctx.drawText(tr, r[1], px + cw - pad - tr.getWidth(r[1]), ry, 0xFFFFFFFF, false);
                ry += rowH;
            }
        }
    }

    public static final class KeystrokesMod extends HudModule {
        final Setting.Bool showMouse = add(new Setting.Bool("Mouse + CPS", true));
        final Setting.Bool showSpace = add(new Setting.Bool("Space bar", true));

        public KeystrokesMod() {
            super("Keystrokes", "WASD, mouse buttons and CPS.");
            style.remove(effect);
        }

        @Override protected int defaultY(int sh) { return sh / 2 - 30; }

        private void key(DrawContext ctx, int bx, int by, int bw, int bh, String label, boolean pressed) {
            int bg = pressed ? Gfx.alpha(accent(), 210) : bgColor();
            Gfx.round(ctx, bx, by, bw, bh, rounding.asInt(), bg);
            Gfx.centered(ctx, label, bx + bw / 2, by + (bh - 8) / 2, pressed ? 0xFFFFFFFF : 0xFFB4B4BE);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            int k = 22, g = 2;
            int cw = k * 3 + g * 2;
            int ch = k * 2 + g;
            if (showMouse.value) ch += g + 20;
            if (showSpace.value) ch += g + 12;
            w = cw; h = ch;
            int px = left(), py = y;
            key(ctx, px + k + g, py, k, k, "W", mc.options.forwardKey.isPressed());
            key(ctx, px, py + k + g, k, k, "A", mc.options.leftKey.isPressed());
            key(ctx, px + k + g, py + k + g, k, k, "S", mc.options.backKey.isPressed());
            key(ctx, px + (k + g) * 2, py + k + g, k, k, "D", mc.options.rightKey.isPressed());
            int cy = py + (k + g) * 2;
            if (showMouse.value) {
                int bw = (cw - g) / 2;
                key(ctx, px, cy, bw, 20, "LMB " + Stats.leftClicks.size(), Stats.lDown);
                key(ctx, px + bw + g, cy, cw - bw - g, 20, "RMB " + Stats.rightClicks.size(), Stats.rDown);
                cy += 20 + g;
            }
            if (showSpace.value) key(ctx, px, cy, cw, 12, "SPACE", mc.options.jumpKey.isPressed());
        }
    }

    public static final class ArmorHudMod extends HudModule {
        final Setting.Bool percent = add(new Setting.Bool("Durability %", true));
        final Setting.Bool offhand = add(new Setting.Bool("Offhand", true));

        public ArmorHudMod() { super("ArmorHud", "Armor pieces with durability."); }

        @Override protected int defaultX(int sw) { return sw / 2 + 98; }
        @Override protected int defaultY(int sh) { return sh - 46; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<ItemStack> items = new ArrayList<>();
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot s : slots) {
                ItemStack st = mc.player.getEquippedStack(s);
                if (!st.isEmpty()) items.add(st);
            }
            if (offhand.value) {
                ItemStack st = mc.player.getEquippedStack(EquipmentSlot.OFFHAND);
                if (!st.isEmpty()) items.add(st);
            }
            if (items.isEmpty()) { w = 0; h = 0; return; }
            int cell = 20;
            w = items.size() * cell + 4;
            h = 20 + (percent.value ? 10 : 0);
            int px = left(), py = y;
            panel(ctx, px, py, w, h);
            for (int i = 0; i < items.size(); i++) {
                ItemStack st = items.get(i);
                int ix = px + 4 + i * cell, iy = py + 3;
                ctx.drawItem(st, ix, iy);
                ctx.drawStackOverlay(tr, st, ix, iy);
                if (percent.value && st.isDamageable()) {
                    int max = st.getMaxDamage();
                    float f = (max - st.getDamage()) / (float) max;
                    String s = Math.round(f * 100) + "%";
                    ctx.drawText(tr, s, ix + 8 - tr.getWidth(s) / 2, py + 21, Gfx.lerp(0xFFFF4040, 0xFF50FF70, f), true);
                }
            }
        }
    }

    public static final class PotionHudMod extends HudModule {
        public PotionHudMod() { super("PotionHud", "Active status effects with timers."); }

        @Override protected int defaultY(int sh) { return 100; }

        private static String roman(int n) {
            String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
            return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            List<StatusEffectInstance> list = new ArrayList<>();
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                boolean fake = e.getEffectType().equals(StatusEffects.NIGHT_VISION) && e.getDuration() > 100000;
                if (!fake) list.add(e);
            }
            if (list.isEmpty()) { w = 0; h = 0; return; }
            list.sort(Comparator.comparingInt((StatusEffectInstance e) -> -e.getDuration()));
            int rowH = 11, pad = 5;
            String[] names = new String[list.size()];
            String[] times = new String[list.size()];
            int cw = 60;
            for (int i = 0; i < list.size(); i++) {
                StatusEffectInstance e = list.get(i);
                names[i] = e.getEffectType().value().getName().getString() + (e.getAmplifier() > 0 ? " " + roman(e.getAmplifier() + 1) : "");
                if (e.isInfinite()) times[i] = "inf";
                else { int s = e.getDuration() / 20; times[i] = (s / 60) + ":" + String.format("%02d", s % 60); }
                cw = Math.max(cw, 8 + tr.getWidth(names[i]) + 14 + tr.getWidth(times[i]) + pad * 2);
            }
            int ch = list.size() * rowH + pad * 2 - 1;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < list.size(); i++) {
                int ry = py + pad + i * rowH;
                int col = 0xFF000000 | list.get(i).getEffectType().value().getColor();
                ctx.fill(px + pad + 2, ry + 3, px + pad + 6, ry + 7, col);
                ctx.drawText(tr, names[i], px + pad + 10, ry, 0xFFFFFFFF, true);
                ctx.drawText(tr, times[i], px + cw - pad - tr.getWidth(times[i]), ry, 0xFFA8A8B3, false);
            }
        }
    }

    public static final class CoordinatesMod extends HudModule {
        final Setting.Bool nether = add(new Setting.Bool("Nether coords", true));
        final Setting.Bool facing = add(new Setting.Bool("Direction", true));

        public CoordinatesMod() { super("Coordinates", "Big coordinates with direction."); }

        @Override protected int defaultY(int sh) { return sh - 52; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            int bx = mc.player.getBlockX(), by = mc.player.getBlockY(), bz = mc.player.getBlockZ();
            List<String> lines = new ArrayList<>();
            boolean hideC = Player.StreamerModeMod.coords();
            lines.add(hideC ? "XYZ  hidden" : "XYZ  " + bx + "  " + by + "  " + bz);
            if (!hideC && nether.value && mc.world != null) {
                if (mc.world.getRegistryKey() == World.OVERWORLD) lines.add("Nether  " + (bx / 8) + "  " + (bz / 8));
                else if (mc.world.getRegistryKey() == World.NETHER) lines.add("Overworld  " + (bx * 8) + "  " + (bz * 8));
            }
            if (facing.value) {
                String d = mc.player.getHorizontalFacing().asString();
                String axis = switch (d) { case "north" -> "-Z"; case "south" -> "+Z"; case "west" -> "-X"; default -> "+X"; };
                lines.add("Facing  " + Character.toUpperCase(d.charAt(0)) + d.substring(1) + " (" + axis + ")");
            }
            int pad = 6, rowH = 11, cw = 60;
            for (String l : lines) cw = Math.max(cw, tr.getWidth(l) + pad * 2 + 2);
            int ch = lines.size() * rowH + pad * 2 - 2;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < lines.size(); i++) ctx.drawText(tr, lines.get(i), px + pad + 2, py + pad + i * rowH - 1, i == 0 ? 0xFFFFFFFF : 0xFFB4B4BE, true);
        }
    }

    public static final class CompassMod extends HudModule {
        public CompassMod() { super("Compass", "Scrolling compass bar."); }

        @Override protected int defaultX(int sw) { return sw / 2 - 100; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            float yaw = mc.player.getYaw();
            float bearing = ((yaw + 180f) % 360f + 360f) % 360f;
            int cw = 200, ch = 20;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            float ppd = cw / 180f;
            ctx.enableScissor(px + 3, py, px + cw - 3, py + ch);
            int start = (int) Math.floor((bearing - 95) / 15f) * 15;
            for (int d = start; d <= bearing + 95; d += 15) {
                int sx = px + cw / 2 + Math.round((d - bearing) * ppd);
                int n = ((d % 360) + 360) % 360;
                String lab = switch (n) {
                    case 0 -> "N"; case 90 -> "E"; case 180 -> "S"; case 270 -> "W";
                    case 45 -> "NE"; case 135 -> "SE"; case 225 -> "SW"; case 315 -> "NW";
                    default -> null;
                };
                if (lab != null) Gfx.centered(ctx, lab, sx, py + 3, lab.length() == 1 ? 0xFFFFFFFF : 0xFF8E8E9A);
                else ctx.fill(sx, py + ch - 6, sx + 1, py + ch - 3, 0xFF6A6A76);
            }
            ctx.disableScissor();
            ctx.fill(px + cw / 2 - 1, py + ch - 3, px + cw / 2 + 1, py + ch, accent());
            Gfx.centered(ctx, Math.round(bearing) + "\u00b0", px + cw / 2, py + ch + 2, accent());
        }
    }

    public static final class ItemCounterMod extends HudModule {
        final Setting.Bool hideEmpty = add(new Setting.Bool("Hide empty", false));

        public ItemCounterMod() { super("ItemCounter", "Totems, golden apples, pearls, fireworks."); }

        @Override protected int defaultX(int sw) { return sw - 54; }
        @Override protected int defaultY(int sh) { return sh / 2 - 30; }

        private int count(MinecraftClient mc, Item... items) {
            int n = 0;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                for (Item it : items) if (st.isOf(it)) n += st.getCount();
            }
            return n;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            Item[][] groups = {{Items.TOTEM_OF_UNDYING}, {Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE}, {Items.ENDER_PEARL}, {Items.FIREWORK_ROCKET}};
            List<Item> icons = new ArrayList<>();
            List<Integer> counts = new ArrayList<>();
            for (Item[] g : groups) {
                int c = count(mc, g);
                if (c == 0 && hideEmpty.value) continue;
                icons.add(g[0]); counts.add(c);
            }
            if (icons.isEmpty()) { w = 0; h = 0; return; }
            int rowH = 18;
            w = 52; h = icons.size() * rowH + 4;
            int px = left(), py = y;
            panel(ctx, px, py, w, h);
            for (int i = 0; i < icons.size(); i++) {
                int ry = py + 3 + i * rowH;
                ctx.drawItem(new ItemStack(icons.get(i)), px + 5, ry);
                String s = "x" + counts.get(i);
                ctx.drawText(mc.textRenderer, s, px + w - 5 - mc.textRenderer.getWidth(s), ry + 4, counts.get(i) == 0 ? 0xFF7A7A86 : 0xFFFFFFFF, true);
            }
        }
    }

    public static final class SessionMod extends HudModule {
        public SessionMod() { super("Session", "Playtime, deaths and distance."); }

        @Override protected int defaultY(int sh) { return sh / 2 + 10; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            long s = (System.currentTimeMillis() - Stats.sessionStart) / 1000;
            String[][] rows = {
                    {"Playtime", String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)},
                    {"Deaths", String.valueOf(Stats.deaths)},
                    {"Distance", String.format(Locale.ROOT, "%.0f m", Stats.distance)}
            };
            TextRenderer tr = mc.textRenderer;
            int pad = 6, rowH = 11, cw = 90;
            for (String[] r : rows) cw = Math.max(cw, tr.getWidth(r[0]) + tr.getWidth(r[1]) + pad * 2 + 14);
            int ch = rows.length * rowH + pad * 2 - 2;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < rows.length; i++) {
                int ry = py + pad - 1 + i * rowH;
                ctx.drawText(tr, rows[i][0], px + pad + 2, ry, 0xFFA8A8B3, false);
                ctx.drawText(tr, rows[i][1], px + cw - pad - tr.getWidth(rows[i][1]), ry, 0xFFFFFFFF, true);
            }
        }
    }

    public static final class ZoomMod extends Module {
        final Setting.Num fov = add(new Setting.Num("Zoom FOV", 30, 30, 80, 1));
        final Setting.Num smooth = add(new Setting.Num("Smoothness", 10, 3, 30, 1));
        private boolean applied;
        private int original;

        public ZoomMod() {
            super("Zoom", "Zooms the camera in.", Category.VISUALS);
            key = GLFW.GLFW_KEY_C;
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (CameraFx.fovHooked()) {
                CameraFx.zoomSpeed = smooth.asFloat();
                CameraFx.zoomTarget = Math.min(1f, fov.asFloat() / Math.max(30f, mc.options.getFov().getValue()));
                if (applied) restore();
                return;
            }
            var opt = mc.options.getFov();
            if (!applied) { original = opt.getValue(); applied = true; }
            int target = fov.asInt();
            if (opt.getValue() != target) opt.setValue(target);
        }

        private void restore() {
            if (!applied) return;
            MinecraftClient.getInstance().options.getFov().setValue(original);
            applied = false;
        }

        @Override public void onDisable() { CameraFx.zoomTarget = 1f; restore(); }
        @Override public void onShutdown() { CameraFx.zoomTarget = 1f; restore(); }
    }

    public static final class FullbrightMod extends Module {
        public FullbrightMod() { super("Fullbright", "Makes everything bright (client-side).", Category.VISUALS); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
            }
        }

        @Override
        public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }

    // =================================================================== OTHER

    public static final class InterfaceMod extends Module {
        final Setting.Mode preset = add(new Setting.Mode("Theme", 0, "Orange", "Violet", "Cyan", "Mint", "Rose", "Rainbow", "Custom"));
        final Setting.Col custom = add(new Setting.Col("Custom color", 0.55f, 0.9f, 1f));
        final Setting.Mode textStyle = add(new Setting.Mode("Text style", 1, TextFx.NAMES));
        final Setting.Num dim = add(new Setting.Num("Background dim", 110, 0, 220, 10));
        final Setting.Num speed = add(new Setting.Num("Animation speed", 1.0, 0.5, 2.0, 0.1));
        final Setting.Action resetHud = add(new Setting.Action("Reset HUD positions", () -> {
            for (Module m : ModuleManager.ALL) if (m instanceof HudModule hm) hm.resetPosition();
            ModuleManager.dirty = true;
        }));
        final Setting.Action saveNow = add(new Setting.Action("Save config", ModuleManager::save));

        public InterfaceMod() {
            super("Interface", "Menu theme, animations and layout.", Category.OTHER);
            key = GLFW.GLFW_KEY_RIGHT_SHIFT;
            Theme.preset = preset;
            Theme.custom = custom;
            custom.visible = () -> preset.is("Custom");
        }

        @Override public boolean alwaysOn() { return true; }
    }

    public static final class NotificationsMod extends Module {
        final Setting.Num duration = add(new Setting.Num("Duration (s)", 3, 1, 8, 0.5));
        final Setting.Bool toggles = add(new Setting.Bool("Module toggles", true));

        public NotificationsMod() {
            super("Notifications", "Animated toast messages.", Category.OTHER);
            enabled = true;
        }
    }

    public static final class DeathCoordsMod extends Module {
        final Setting.Bool dimension = add(new Setting.Bool("Show dimension", true));

        public DeathCoordsMod() {
            super("DeathCoords", "Prints your death coordinates in chat.", Category.OTHER);
            enabled = true;
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (!Stats.justDied) return;
            String msg = "\u00a78[\u00a76Gordey\u00a78] \u00a77Вы умерли: \u00a7e" + Stats.deathX + " " + Stats.deathY + " " + Stats.deathZ
                    + (dimension.value ? " \u00a78(" + Stats.deathDim + ")" : "");
            mc.player.sendMessage(Text.literal(msg), false);
        }
    }

    public static final class WindowTitleMod extends Module {
        final Setting.Mode style = add(new Setting.Mode("Style", 1, "Gordey Visuals", "Gordey Visuals | FPS", "Gordey Visuals | 1.21.11"));
        private int t;

        public WindowTitleMod() { super("WindowTitle", "Custom game window title.", Category.OTHER); }

        @Override
        public void onTick(MinecraftClient mc) {
            if (t++ % 10 != 0) return;
            String s = style.get();
            if (style.index == 1) s = "Gordey Visuals | " + mc.getCurrentFps() + " FPS";
            GLFW.glfwSetWindowTitle(mc.getWindow().getHandle(), s);
        }

        @Override public void onDisable() { MinecraftClient.getInstance().updateWindowTitle(); }
    }
}

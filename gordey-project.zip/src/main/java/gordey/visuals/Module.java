package gordey.visuals;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        VISUALS("Visuals"), OTHER("Other"), PLAYER("Player");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public final String name, description;
    public Category category;
    public boolean enabled;
    public int key = -1;
    public final List<Setting> settings = new ArrayList<>();

    // GUI state
    public boolean expanded, keyDown;
    public float expandAnim, enableAnim;

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected <S extends Setting> S add(S s) { settings.add(s); return s; }

    public List<Setting> allSettings() { return settings; }

    public boolean alwaysOn() { return false; }

    /** Action modules run onAction() when their bind is pressed (instead of toggling). */
    public boolean actionBind() { return false; }
    public void onAction(MinecraftClient mc) { }

    public void setEnabled(boolean v) {
        if (alwaysOn() || v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
        Notifier.moduleToggled(this, v);
        ModuleManager.dirty = true;
    }

    public void toggle() { setEnabled(!enabled); }

    public void onEnable() { }
    public void onDisable() { }
    public void onTick(MinecraftClient mc) { }
    public void onShutdown() { }
}

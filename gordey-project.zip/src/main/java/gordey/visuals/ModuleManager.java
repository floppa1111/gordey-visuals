package gordey.visuals;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private ModuleManager() { }

    public static final List<Module> ALL = new ArrayList<>();
    public static Mods.NotificationsMod notifications;
    public static Mods.InterfaceMod iface;
    public static boolean dirty;
    private static int saveTimer;
    private static boolean hadPlayer;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("gordey_visuals.json");

    public static void init() {
        iface = new Mods.InterfaceMod();
        notifications = new Mods.NotificationsMod();

        ALL.add(new Mods.WatermarkMod());
        ALL.add(new Extra.TargetHudMod());
        ALL.add(new Ui.ModuleListMod());
        ALL.add(new Mods.KeystrokesMod());
        ALL.add(new Mods.ArmorHudMod());
        ALL.add(new Mods.PotionHudMod());
        ALL.add(new Mods.CoordinatesMod());
        ALL.add(new Mods.CompassMod());
        ALL.add(new Ui.FpsGraphMod());
        ALL.add(new Mods.ItemCounterMod());
        ALL.add(new Mods.SessionMod());
        ALL.add(new Mods.ZoomMod());
        ALL.add(new Mods.FullbrightMod());
        ALL.add(new Ui.ClockMod());
        ALL.add(new Ui.PlayerStatsMod());
        ALL.add(new Extra.HeldItemMod());
        ALL.add(new Extra.ServerInfoMod());
        ALL.add(new Extra.WorldInfoMod());
        ALL.add(new Extra.ComboCounterMod());
        ALL.add(new Extra.CooldownBarMod());
        ALL.add(new Extra.CrosshairRingMod());
        ALL.add(new Extra.LowHealthMod());
        ALL.add(new Fx.CameraFxMod());
        ALL.add(new Fx.AtmosphereMod());
        ALL.add(new Fx.ScreenTintMod());
        ALL.add(new Fx.HitMarkerMod());
        ALL.add(new Fx.StatusFlagsMod());
        ALL.add(new Media.NowPlayingMod());
        ALL.add(new Media.LyricsMod());

        ALL.add(iface);
        ALL.add(notifications);
        ALL.add(new Mods.DeathCoordsMod());
        ALL.add(new Player.AutoRespawnMod());
        ALL.add(new Mods.WindowTitleMod());
        ALL.add(new Extra.WelcomeMod());
        ALL.add(new Fx.PickupToastsMod());
        ALL.add(new Fx.DurabilityWarningMod());

        ALL.add(new Player.HealingHelperMod());
        ALL.add(new Player.CooldownsMod());
        ALL.add(new Player.ItemHighlighterMod());
        ALL.add(new Player.ItemScrollerMod());
        ALL.add(new Player.PickupLoggerMod());
        ALL.add(new Player.LockSlotMod());
        ALL.add(new Player.ElytraSwapMod());
        ALL.add(new Player.FastSwapMod());
        ALL.add(new Player.AutoEatMod());
        ALL.add(new Player.TotemTrackerMod());
        ALL.add(new Player.StreamerModeMod());
        ALL.add(new Player.PvpSafeMod());
        ALL.add(new Player.SoundControllerMod());
        ALL.add(new Wx.PredictionsMod());

        ALL.add(new Wx.FloatersMod());
        ALL.add(new Wx.BlockOverlayMod());
        ALL.add(new Wx.HotbarGlideMod());

        java.util.Set<String> playerTab = java.util.Set.of("ArmorHud", "PotionHud", "ItemCounter", "Session", "PlayerStats",
                "HeldItem", "Coordinates", "StatusFlags", "CooldownBar", "ComboCounter", "Keystrokes", "DeathCoords",
                "PickupToasts", "DurabilityWarning");
        for (Module m : ALL) if (playerTab.contains(m.name)) m.category = Module.Category.PLAYER;
        load();
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) { Stats.reset(); hadPlayer = false; Stats.justJoined = false; return; }
        Stats.justJoined = !hadPlayer;
        hadPlayer = true;
        Stats.tick(mc);

        long handle = mc.getWindow().getHandle();
        for (Module m : ALL) {
            if (m.key < 0 || !Keys.valid(m.key)) continue;
            boolean d = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
            if (d && !m.keyDown) {
                net.minecraft.client.gui.screen.Screen cs = mc.currentScreen;
                if (m.actionBind()) {
                    if (m.enabled && (cs == null || cs instanceof net.minecraft.client.gui.screen.ingame.HandledScreen)) m.onAction(mc);
                } else if (cs == null) {
                    if (m instanceof Mods.InterfaceMod) mc.setScreen(new GordeyScreen());
                    else m.toggle();
                }
            }
            m.keyDown = d;
        }

        for (Module m : ALL) if (m.enabled || m.alwaysOn()) m.onTick(mc);

        boolean wantMedia = false;
        for (Module m : ALL) if (m.enabled && (m instanceof Media.NowPlayingMod || m instanceof Media.LyricsMod)) wantMedia = true;
        Media.Tracker.setActive(wantMedia);

        if (dirty && ++saveTimer > 100) { save(); dirty = false; saveTimer = 0; }
    }

    public static void shutdown() {
        Media.Tracker.setActive(false);
        for (Module m : ALL) m.onShutdown();
        save();
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled || m.alwaysOn());
                o.addProperty("key", m.key);
                if (m instanceof HudModule h) {
                    if (h.x != HudModule.UNSET) o.addProperty("x", h.x);
                    if (h.y != HudModule.UNSET) o.addProperty("y", h.y);
                }
                JsonObject s = new JsonObject();
                for (Setting st : m.allSettings()) {
                    JsonElement e = st.save();
                    if (!e.isJsonNull()) s.add(st.name, e);
                }
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(FILE, new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) { }
    }

    private static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject root = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : ALL) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean() || m.alwaysOn();
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (m instanceof HudModule h) {
                    if (o.has("x")) h.x = o.get("x").getAsInt();
                    if (o.has("y")) h.y = o.get("y").getAsInt();
                }
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : m.allSettings()) {
                        try { if (s.has(st.name)) st.load(s.get(st.name)); } catch (Exception ignored) { }
                    }
                }
            }
        } catch (Exception ignored) { }
    }
}

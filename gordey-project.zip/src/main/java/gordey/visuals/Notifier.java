package gordey.visuals;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class Notifier {
    private Notifier() { }

    private static final class Toast {
        String title, msg; int color; long born; long life;
    }

    private static final List<Toast> TOASTS = new ArrayList<>();

    public static void moduleToggled(Module m, boolean on) {
        Mods.NotificationsMod n = ModuleManager.notifications;
        if (n == null || !n.enabled || !n.toggles.value) return;
        push(m.name, on ? "Enabled" : "Disabled", on ? Theme.accent() : 0xFF8A8A96);
    }

    public static void push(String title, String msg, int color) {
        Mods.NotificationsMod n = ModuleManager.notifications;
        if (n == null || !n.enabled) return;
        Toast t = new Toast();
        t.title = title; t.msg = msg; t.color = color; t.born = System.currentTimeMillis();
        t.life = (long) (n.duration.value * 1000);
        TOASTS.add(t);
        while (TOASTS.size() > 5) TOASTS.remove(0);
    }

    public static void render(DrawContext ctx, int sw, int sh) {
        long now = System.currentTimeMillis();
        int idx = 0;
        for (Iterator<Toast> it = TOASTS.iterator(); it.hasNext(); ) {
            Toast t = it.next();
            long age = now - t.born;
            if (age > t.life) { it.remove(); continue; }
            float in = Gfx.easeOut(age / 300f);
            float out = Gfx.easeOut((t.life - age) / 300f);
            float k = Math.min(in, out);
            int w = Math.max(120, Math.max(Gfx.width(t.title), Gfx.width(t.msg)) + 24), h = 28;
            int x = sw - 8 - Math.round((w + 8) * k);
            int y = sh - 60 - idx * (h + 5);
            Gfx.round(ctx, x - 1, y - 1, w + 2, h + 2, 5, Gfx.alpha(t.color, 70));
            Gfx.round(ctx, x, y, w, h, 4, 0xEE0E0E13);
            ctx.fill(x + 4, y + 5, x + 6, y + h - 5, t.color);
            Gfx.text(ctx, t.title, x + 11, y + 6, 0xFFFFFFFF);
            Gfx.textPlain(ctx, t.msg, x + 11, y + 17, 0xFFA8A8B3);
            float p = 1f - age / (float) t.life;
            ctx.fill(x + 4, y + h - 3, x + 4 + Math.round((w - 8) * p), y + h - 2, Gfx.alpha(t.color, 200));
            idx++;
        }
    }
}

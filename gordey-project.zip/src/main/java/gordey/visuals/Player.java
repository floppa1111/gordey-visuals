package gordey.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import gordey.visuals.mixin.HandledScreenAccessor;
import gordey.visuals.mixin.SoundInstanceAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Everything for the "Player" tab. */
public final class Player {
    private Player() { }

    // ------------------------------------------------------------------ helpers
    static <T> T find(Class<T> c) {
        for (Module m : ModuleManager.ALL) if (c.isInstance(m)) return c.cast(m);
        return null;
    }

    static int hotbarX(int sw, int i) { return sw / 2 - 88 + i * 20; }
    static int hotbarY(int sh) { return sh - 19; }

    static int count(MinecraftClient mc, Item... items) {
        int n = 0;
        var inv = mc.player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            for (Item it : items) if (st.isOf(it)) n += st.getCount();
        }
        return n;
    }

    static int hotbarIndex(MinecraftClient mc, Item item) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) if (inv.getStack(i).isOf(item)) return i;
        return -1;
    }

    static Slot focused(HandledScreen<?> hs) {
        try { return ((HandledScreenAccessor) hs).gordey$getFocusedSlot(); } catch (Throwable t) { return null; }
    }

    static boolean key(long h, int k) { return GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS; }

    static void say(MinecraftClient mc, String msg) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("\u00a78[\u00a76Gordey\u00a78] " + msg), false);
    }

    static String path(ItemStack st) { return Registries.ITEM.getId(st.getItem()).getPath(); }

    static void highlight(DrawContext ctx, int x, int y, String style, int rgb) {
        long t = System.currentTimeMillis();
        switch (style) {
            case "Fill" -> ctx.fill(x - 1, y - 1, x + 17, y + 17, Gfx.alpha(rgb, 120));
            case "Glow" -> { for (int i = 3; i >= 1; i--) Gfx.round(ctx, x - i, y - i, 16 + i * 2, 16 + i * 2, 2 + i, Gfx.alpha(rgb, 30 + (4 - i) * 12)); Gfx.outline(ctx, x - 1, y - 1, 18, 18, 0, Gfx.alpha(rgb, 230)); }
            case "Pulse" -> { int a = 70 + (int) (150 * (0.5 + 0.5 * Math.sin(t / 250.0))); ctx.fill(x - 1, y - 1, x + 17, y + 17, Gfx.alpha(rgb, a / 2)); Gfx.outline(ctx, x - 1, y - 1, 18, 18, 0, Gfx.alpha(rgb, a + 30)); }
            default -> Gfx.outline(ctx, x - 1, y - 1, 18, 18, 0, Gfx.alpha(rgb, 240));
        }
    }

    static int resourceColor(ItemStack st) {
        return switch (path(st)) {
            case "golden_apple" -> 0xFFD83B;
            case "enchanted_golden_apple" -> 0xB86EFF;
            case "ender_pearl" -> 0x2FD6C0;
            case "totem_of_undying" -> 0x7CFF4D;
            case "experience_bottle" -> 0x66FF66;
            case "firework_rocket" -> 0xFF5555;
            case "arrow", "spectral_arrow", "tipped_arrow" -> 0xC08A5A;
            case "potion", "splash_potion", "lingering_potion" -> 0xFF6EC7;
            case "golden_carrot" -> 0xFFA64D;
            case "water_bucket" -> 0x4DA6FF;
            case "lava_bucket" -> 0xFF7A1A;
            case "end_crystal" -> 0xFF8AE6;
            case "obsidian" -> 0x7A55CC;
            case "tnt" -> 0xFF3B3B;
            case "cobweb" -> 0xE0E0E0;
            default -> 0;
        };
    }

    static void drawLock(DrawContext ctx, int x, int y) {
        ctx.fill(x + 8, y + 9, x + 15, y + 15, 0xFFE24B4B);
        ctx.fill(x + 9, y + 6, x + 10, y + 9, 0xFFE24B4B);
        ctx.fill(x + 13, y + 6, x + 14, y + 9, 0xFFE24B4B);
        ctx.fill(x + 9, y + 6, x + 14, y + 7, 0xFFE24B4B);
        ctx.fill(x + 11, y + 11, x + 12, y + 13, 0xFF2A0A0A);
    }

    static void drawHotbarLocks(DrawContext ctx, MinecraftClient mc, int sw, int sh) {
        LockSlotMod ls = find(LockSlotMod.class);
        if (ls == null || !ls.enabled) return;
        for (int i = 0; i < 9; i++) if (LockSlotMod.isLocked(i)) drawLock(ctx, hotbarX(sw, i), hotbarY(sh));
    }

    // ------------------------------------------------------------------ screen hooks
    public static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof HandledScreen<?> hs) {
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, td) -> renderInventory(ctx, hs));
            }
            if (screen instanceof GameMenuScreen) hookMenu(screen);
        });
    }

    private static void renderInventory(DrawContext ctx, HandledScreen<?> hs) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int ox, oy;
        try {
            HandledScreenAccessor a = (HandledScreenAccessor) hs;
            ox = a.gordey$getX();
            oy = a.gordey$getY();
        } catch (Throwable t) { return; }
        ItemHighlighterMod hl = find(ItemHighlighterMod.class);
        LockSlotMod ls = find(LockSlotMod.class);
        boolean doHl = hl != null && hl.enabled, doLock = ls != null && ls.enabled;
        if (!doHl && !doLock) return;
        ScreenHandler handler = hs.getScreenHandler();
        for (Slot s : handler.slots) {
            int x = ox + s.x, y = oy + s.y;
            ItemStack st = s.getStack();
            if (doHl && !st.isEmpty()) {
                int c = resourceColor(st);
                if (c != 0) {
                    ctx.fill(x, y, x + 16, y + 16, Gfx.alpha(c, hl.strength.asInt()));
                    if (hl.outline.value) Gfx.outline(ctx, x, y, 16, 16, 0, Gfx.alpha(c, 230));
                }
            }
            if (doLock && s.inventory == mc.player.getInventory() && LockSlotMod.isLocked(s.getIndex())) drawLock(ctx, x, y);
        }
    }

    private static void hookMenu(net.minecraft.client.gui.screen.Screen screen) {
        List<ClickableWidget> btns = new ArrayList<>();
        Map<ClickableWidget, Text> orig = new HashMap<>();
        for (ClickableWidget b : Screens.getButtons(screen)) {
            Text m = b.getMessage();
            if (m.getContent() instanceof TranslatableTextContent t && (t.getKey().equals("menu.disconnect") || t.getKey().equals("menu.returnToMenu"))) {
                btns.add(b);
                orig.put(b, m);
            }
        }
        if (btns.isEmpty()) return;
        ScreenEvents.afterTick(screen).register(s -> {
            PvpSafeMod mod = find(PvpSafeMod.class);
            boolean lock = mod != null && mod.enabled && Stats.inPvp(mod.seconds.asInt());
            for (ClickableWidget b : btns) {
                if (lock) {
                    b.active = false;
                    b.setMessage(Text.literal("PvP lock: " + Stats.pvpLeft(mod.seconds.asInt()) + "s"));
                } else {
                    b.active = true;
                    b.setMessage(orig.get(b));
                }
            }
        });
    }

    // ================================================================ HEALING HELPER
    public static final class HealingHelperMod extends HudModule {
        final Setting.Num below = add(new Setting.Num("Show below HP", 16, 4, 20, 1));
        final Setting.Mode hlStyle = add(new Setting.Mode("Highlight", 3, "Outline", "Fill", "Glow", "Pulse"));
        final Setting.Bool hotbarHl = add(new Setting.Bool("Highlight in hotbar", true));
        private int stage, lastG = -1, lastE = -1;
        private long lastEat;

        public HealingHelperMod() {
            super("HealingHelper", "Shows the right order of healing: golden apple first, then enchanted.");
            category = Category.PLAYER;
        }

        @Override protected int defaultX(int sw) { return sw / 2 + 100; }
        @Override protected int defaultY(int sh) { return sh - 80; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            boolean editing = mc.currentScreen instanceof GordeyScreen;
            int g = count(mc, Items.GOLDEN_APPLE), e = count(mc, Items.ENCHANTED_GOLDEN_APPLE);
            long now = System.currentTimeMillis();
            if (lastG >= 0 && g < lastG) { stage = 1; lastEat = now; }
            if (lastE >= 0 && e < lastE) { stage = 0; lastEat = now; }
            lastG = g; lastE = e;
            if (now - lastEat > 12000) stage = 0;

            if (mc.player.getHealth() >= below.value && !editing) { w = 0; h = 0; return; }

            Item[] order = stage == 0 ? new Item[]{Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE} : new Item[]{Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE};
            Item next = null;
            for (Item it : order) if (count(mc, it) > 0) { next = it; break; }

            int ac = accent();
            int pad = 6, rowH = 20, cw = 118, ch = pad * 2 + rowH * 2 - 2 + 10;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            Gfx.text(ctx, "Healing order", px + pad + 2, py + 4, 0xFFFFFFFF);
            Item[] fixed = {Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE};
            String[] names = {"1  Apple", "2  Enchanted"};
            int[] cnt = {g, e};
            for (int i = 0; i < 2; i++) {
                int ry = py + 16 + i * rowH;
                boolean isNext = fixed[i] == next;
                if (isNext) Gfx.round(ctx, px + 3, ry - 1, cw - 6, 19, 3, Gfx.alpha(ac, 70));
                ctx.drawItem(new ItemStack(fixed[i]), px + pad, ry);
                ctx.drawText(tr, names[i], px + pad + 20, ry + 4, isNext ? ac : 0xFFC8C8D2, true);
                String c = "x" + cnt[i];
                ctx.drawText(tr, c, px + cw - pad - tr.getWidth(c), ry + 4, cnt[i] == 0 ? 0xFFFF6060 : 0xFFFFFFFF, false);
            }
            if (hotbarHl.value && next != null && !editing) {
                int idx = hotbarIndex(mc, next);
                if (idx >= 0) {
                    int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
                    highlight(ctx, hotbarX(sw, idx), hotbarY(sh), hlStyle.get(), ac & 0xFFFFFF);
                }
            }
        }
    }

    // ================================================================ COOLDOWNS
    public static final class CooldownsMod extends HudModule {
        final Setting.Mode layout = add(new Setting.Mode("Layout", 0, "Hotbar overlay", "Row", "Column"));
        final Setting.Mode sweep = add(new Setting.Mode("Sweep", 0, "From top", "From bottom", "Solid"));
        final Setting.Bool seconds = add(new Setting.Bool("Seconds", true));
        final Setting.Col overlayColor = add(new Setting.Col("Overlay color", 0f, 0f, 0.55f));
        final Setting.Num overlayAlpha = add(new Setting.Num("Overlay opacity", 140, 30, 230, 10));

        private static final class Track { float p0; long t0; float total; }
        private final Map<Item, Track> tracks = new HashMap<>();

        public CooldownsMod() {
            super("Cooldowns", "Item cooldown timers with seconds.");
            category = Category.PLAYER;
        }

        @Override protected int defaultX(int sw) { return sw / 2 + 100; }
        @Override protected int defaultY(int sh) { return sh - 120; }

        private void overlay(DrawContext ctx, int x, int y, float p) {
            int col = (overlayAlpha.asInt() << 24) | overlayColor.rgb();
            int hh = Math.max(1, Math.round(16 * Math.min(1f, p)));
            if (sweep.is("From top")) ctx.fill(x, y, x + 16, y + hh, col);
            else if (sweep.is("From bottom")) ctx.fill(x, y + 16 - hh, x + 16, y + 16, col);
            else ctx.fill(x, y, x + 16, y + 16, Gfx.mulAlpha(col, Math.min(1f, p + 0.25f)));
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            var cm = mc.player.getItemCooldownManager();
            var inv = mc.player.getInventory();
            long now = System.currentTimeMillis();
            LinkedHashMap<Item, ItemStack> stacks = new LinkedHashMap<>();
            LinkedHashMap<Item, Float> prog = new LinkedHashMap<>();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (st.isEmpty() || prog.containsKey(st.getItem())) continue;
                float p = cm.getCooldownProgress(st, 0f);
                if (p > 0f) { prog.put(st.getItem(), p); stacks.put(st.getItem(), st); }
            }
            tracks.keySet().removeIf(it -> !prog.containsKey(it));
            Map<Item, String> label = new HashMap<>();
            for (Map.Entry<Item, Float> en : prog.entrySet()) {
                final float cur = en.getValue();
                Track t = tracks.get(en.getKey());
                if (t == null) { t = new Track(); t.p0 = cur; t.t0 = now; tracks.put(en.getKey(), t); }
                float dt = (now - t.t0) / 1000f;
                if (t.total == 0 && cur < t.p0 - 0.03f && dt > 0.1f) t.total = dt / (t.p0 - cur);
                float r = t.total > 0 ? cur * t.total : -1f;
                label.put(en.getKey(), !seconds.value || r < 0 ? "" : (r >= 10 ? String.valueOf(Math.round(r)) : String.format(Locale.ROOT, "%.1f", r)));
            }

            if (layout.is("Hotbar overlay")) {
                w = 0; h = 0;
                int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
                for (int i = 0; i < 9; i++) {
                    ItemStack st = inv.getStack(i);
                    Float p = st.isEmpty() ? null : prog.get(st.getItem());
                    if (p == null) continue;
                    int x = hotbarX(sw, i), y = hotbarY(sh);
                    overlay(ctx, x, y, p);
                    String s = label.get(st.getItem());
                    if (s != null && !s.isEmpty()) ctx.drawText(tr, s, x + 8 - tr.getWidth(s) / 2, y + 4, 0xFFFFFFFF, true);
                }
                return;
            }

            if (prog.isEmpty()) {
                if (!(mc.currentScreen instanceof GordeyScreen)) { w = 0; h = 0; return; }
            }
            List<Item> items = new ArrayList<>(prog.keySet());
            boolean row = layout.is("Row");
            int n = Math.max(1, items.size());
            int cw = row ? n * 26 + 6 : 62;
            int ch = row ? 16 + 14 + 8 : n * 20 + 6;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < items.size(); i++) {
                Item it = items.get(i);
                float p = prog.get(it);
                int ix = row ? px + 5 + i * 26 : px + 5, iy = row ? py + 4 : py + 3 + i * 20;
                ctx.drawItem(stacks.get(it), ix, iy);
                overlay(ctx, ix, iy, p);
                String s = label.get(it);
                if (s != null && !s.isEmpty()) {
                    if (row) ctx.drawText(tr, s, ix + 8 - tr.getWidth(s) / 2, iy + 19, 0xFFFFFFFF, true);
                    else ctx.drawText(tr, s, ix + 22, iy + 4, 0xFFFFFFFF, true);
                }
            }
        }
    }

    // ================================================================ ITEM HIGHLIGHTER
    public static final class ItemHighlighterMod extends Module {
        final Setting.Num strength = add(new Setting.Num("Strength", 90, 30, 200, 10));
        final Setting.Bool outline = add(new Setting.Bool("Outline", true));

        public ItemHighlighterMod() {
            super("ItemHighlighter", "Colors useful PvP resources in your inventory (apples yellow, pearls teal, ...).", Category.PLAYER);
        }
    }

    // ================================================================ ITEM SCROLLER
    public static final class ItemScrollerMod extends Module {
        final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 2, 1, 6, 1));
        final Setting.Bool needShift = add(new Setting.Bool("Hold Shift", true));
        private int lastSlot = -1, wait;

        public ItemScrollerMod() {
            super("ItemScroller", "Hold Shift + LMB and drag over slots to move many items fast.", Category.PLAYER);
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (!(mc.currentScreen instanceof HandledScreen<?> hs)) { lastSlot = -1; return; }
            long hd = mc.getWindow().getHandle();
            boolean shift = key(hd, GLFW.GLFW_KEY_LEFT_SHIFT) || key(hd, GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean lmb = GLFW.glfwGetMouseButton(hd, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (!lmb || (needShift.value && !shift)) { lastSlot = -1; return; }
            if (wait > 0) { wait--; return; }
            Slot s = focused(hs);
            if (s == null || !s.hasStack() || s.id == lastSlot) return;
            mc.interactionManager.clickSlot(hs.getScreenHandler().syncId, s.id, 0, SlotActionType.QUICK_MOVE, mc.player);
            lastSlot = s.id;
            wait = delay.asInt();
        }
    }

    // ================================================================ PICKUP LOGGER
    public static final class PickupLoggerMod extends Module {
        final Setting.Mode filter = add(new Setting.Mode("Filter", 0, "All items", "Donate (named / lore)", "Enchanted"));
        final Setting.Bool toast = add(new Setting.Bool("Also toast", false));
        private Map<String, Integer> last = new HashMap<>();
        private boolean ready;
        private int t;

        public PickupLoggerMod() { super("PickupLogger", "Writes picked-up items into chat.", Category.PLAYER); }

        private boolean pass(ItemStack st) {
            return switch (filter.index) {
                case 1 -> st.contains(DataComponentTypes.CUSTOM_NAME) || st.contains(DataComponentTypes.LORE);
                case 2 -> st.hasGlint();
                default -> true;
            };
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (Stats.justJoined) { ready = false; last = new HashMap<>(); }
            if (++t % 5 != 0) return;
            Map<String, Integer> cur = new HashMap<>();
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (st.isEmpty() || !pass(st)) continue;
                cur.merge(st.getName().getString(), st.getCount(), Integer::sum);
            }
            if (ready) {
                int shown = 0;
                for (Map.Entry<String, Integer> e : cur.entrySet()) {
                    int d = e.getValue() - last.getOrDefault(e.getKey(), 0);
                    if (d > 0 && shown < 4) {
                        say(mc, "\u00a77+" + d + " \u00a7f" + e.getKey());
                        if (toast.value) Notifier.push("+" + d + "  " + e.getKey(), "Picked up", Theme.accent());
                        shown++;
                    }
                }
            }
            last = cur;
            ready = true;
        }
    }

    // ================================================================ LOCK SLOT
    public static final class LockSlotMod extends Module {
        final Setting.Data data = add(new Setting.Data("locked"));
        static LockSlotMod inst;

        public LockSlotMod() {
            super("LockSlot", "Bind = lock/unlock the hovered inventory slot. Locked items can't be dropped.", Category.PLAYER);
            inst = this;
        }

        @Override public boolean actionBind() { return true; }

        static Set<Integer> set() {
            Set<Integer> s = new HashSet<>();
            if (inst == null) return s;
            JsonElement e = inst.data.value;
            if (e != null && e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) s.add(x.getAsInt());
            return s;
        }

        static boolean isLocked(int idx) { return inst != null && inst.enabled && set().contains(idx); }

        public static boolean blockHotbarDrop() {
            MinecraftClient mc = MinecraftClient.getInstance();
            return mc.player != null && isLocked(mc.player.getInventory().getSelectedSlot());
        }

        public static boolean blockClick(int slotId, SlotActionType type, PlayerEntity p) {
            if (inst == null || !inst.enabled || type != SlotActionType.THROW) return false;
            ScreenHandler h = p.currentScreenHandler;
            if (slotId < 0 || slotId >= h.slots.size()) return false;
            Slot s = h.getSlot(slotId);
            return s.inventory == p.getInventory() && isLocked(s.getIndex());
        }

        @Override
        public void onAction(MinecraftClient mc) {
            if (!(mc.currentScreen instanceof HandledScreen<?> hs)) return;
            Slot s = focused(hs);
            if (s == null || s.inventory != mc.player.getInventory()) return;
            Set<Integer> cur = set();
            if (!cur.remove(s.getIndex())) cur.add(s.getIndex());
            JsonArray a = new JsonArray();
            for (int i : cur) a.add(i);
            data.value = a;
            ModuleManager.dirty = true;
        }
    }

    // ================================================================ ELYTRA SWAP
    public static final class ElytraSwapMod extends Module {
        public ElytraSwapMod() {
            super("ElytraSwap", "Bind = swap elytra and chestplate with one key press.", Category.PLAYER);
        }

        @Override public boolean actionBind() { return true; }

        @Override
        public void onAction(MinecraftClient mc) {
            ScreenHandler h = mc.player.playerScreenHandler;
            boolean wearingElytra = h.getSlot(6).getStack().isOf(Items.ELYTRA);
            int src = -1;
            for (int i = 9; i <= 44; i++) {
                ItemStack st = h.getSlot(i).getStack();
                if (st.isEmpty()) continue;
                if (wearingElytra ? path(st).endsWith("_chestplate") : st.isOf(Items.ELYTRA)) { src = i; break; }
            }
            if (src < 0) { Notifier.push("ElytraSwap", wearingElytra ? "No chestplate found" : "No elytra found", 0xFFFF6060); return; }
            var im = mc.interactionManager;
            im.clickSlot(h.syncId, src, 0, SlotActionType.PICKUP, mc.player);
            im.clickSlot(h.syncId, 6, 0, SlotActionType.PICKUP, mc.player);
            im.clickSlot(h.syncId, src, 0, SlotActionType.PICKUP, mc.player);
        }
    }

    // ================================================================ FAST SWAP
    public static final class FastSwapMod extends Module {
        final Setting.Mode item = add(new Setting.Mode("Item", 0, "Totem", "Golden Apple", "Enchanted Apple", "Ender Pearl", "Firework", "Shield", "Water Bucket"));
        final Setting.Mode target = add(new Setting.Mode("Put into", 0, "Offhand", "Hotbar"));

        public FastSwapMod() {
            super("FastSwap", "Bind = quickly bring the chosen item into your hand.", Category.PLAYER);
        }

        @Override public boolean actionBind() { return true; }

        private Item want() {
            return switch (item.get()) {
                case "Golden Apple" -> Items.GOLDEN_APPLE;
                case "Enchanted Apple" -> Items.ENCHANTED_GOLDEN_APPLE;
                case "Ender Pearl" -> Items.ENDER_PEARL;
                case "Firework" -> Items.FIREWORK_ROCKET;
                case "Shield" -> Items.SHIELD;
                case "Water Bucket" -> Items.WATER_BUCKET;
                default -> Items.TOTEM_OF_UNDYING;
            };
        }

        @Override
        public void onAction(MinecraftClient mc) {
            Item w = want();
            ScreenHandler h = mc.player.playerScreenHandler;
            var im = mc.interactionManager;
            if (target.is("Offhand")) {
                if (h.getSlot(45).getStack().isOf(w)) return;
                for (int i = 9; i <= 44; i++) {
                    if (h.getSlot(i).getStack().isOf(w)) { im.clickSlot(h.syncId, i, 40, SlotActionType.SWAP, mc.player); return; }
                }
                Notifier.push("FastSwap", "Item not found", 0xFFFF6060);
            } else {
                int hb = hotbarIndex(mc, w);
                if (hb >= 0) { mc.player.getInventory().setSelectedSlot(hb); return; }
                int sel = mc.player.getInventory().getSelectedSlot();
                for (int i = 9; i <= 35; i++) {
                    if (h.getSlot(i).getStack().isOf(w)) { im.clickSlot(h.syncId, i, sel, SlotActionType.SWAP, mc.player); return; }
                }
                Notifier.push("FastSwap", "Item not found", 0xFFFF6060);
            }
        }
    }

    // ================================================================ AUTO EAT
    public static final class AutoEatMod extends Module {
        final Setting.Num hunger = add(new Setting.Num("Eat at hunger <=", 14, 1, 19, 1));
        final Setting.Mode pick = add(new Setting.Mode("Food choice", 0, "First in hotbar", "Largest stack", "Smallest stack"));
        final Setting.Num gap = add(new Setting.Num("Pause between (s)", 1.5, 0, 10, 0.5));
        final Setting.Bool notPvp = add(new Setting.Bool("Pause in PvP", true));
        final Setting.Bool golden = add(new Setting.Bool("Allow golden apples", false));
        final Setting.Bool autoOff = add(new Setting.Bool("Disable if no food", true));
        private boolean eating;
        private int prevSlot, ticks, cooldown;

        public AutoEatMod() { super("AutoEat", "Eats food from the hotbar when you are hungry.", Category.PLAYER); }

        private boolean allowed(ItemStack st) {
            if (!st.contains(DataComponentTypes.FOOD)) return false;
            String p = path(st);
            if (p.equals("rotten_flesh") || p.equals("spider_eye") || p.equals("poisonous_potato") || p.equals("pufferfish")
                    || p.equals("chorus_fruit") || p.equals("suspicious_stew")) return false;
            if (!golden.value && (p.equals("golden_apple") || p.equals("enchanted_golden_apple"))) return false;
            return true;
        }

        private int findFood(MinecraftClient mc) {
            var inv = mc.player.getInventory();
            int best = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack st = inv.getStack(i);
                if (st.isEmpty() || !allowed(st)) continue;
                if (best < 0) { best = i; if (pick.is("First in hotbar")) break; continue; }
                int a = st.getCount(), b = inv.getStack(best).getCount();
                if ((pick.is("Largest stack") && a > b) || (pick.is("Smallest stack") && a < b)) best = i;
            }
            return best;
        }

        private void finish(MinecraftClient mc) {
            mc.options.useKey.setPressed(false);
            mc.player.getInventory().setSelectedSlot(prevSlot);
            eating = false;
            cooldown = (int) (gap.value * 20);
        }

        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (eating && mc.player != null) finish(mc);
        }

        @Override
        public void onTick(MinecraftClient mc) {
            if (cooldown > 0) cooldown--;
            if (eating) {
                ticks++;
                mc.options.useKey.setPressed(true);
                if ((!mc.player.isUsingItem() && ticks > 4) || ticks > 80) finish(mc);
                return;
            }
            if (mc.currentScreen != null || cooldown > 0 || mc.player.isUsingItem()) return;
            if (mc.player.getHungerManager().getFoodLevel() > hunger.asInt()) return;
            if (notPvp.value && Stats.inPvp(8)) return;
            int slot = findFood(mc);
            if (slot < 0) {
                if (autoOff.value) { setEnabled(false); Notifier.push("AutoEat", "No food in hotbar - turned off", 0xFFFF6060); }
                return;
            }
            prevSlot = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            mc.options.useKey.setPressed(true);
            eating = true;
            ticks = 0;
        }
    }

    // ================================================================ TOTEM TRACKER
    public static final class TotemTrackerMod extends Module {
        final Setting.Bool chat = add(new Setting.Bool("Chat message", true));
        final Setting.Bool toast = add(new Setting.Bool("Toast", true));
        static TotemTrackerMod inst;
        private final Map<String, Integer> pops = new HashMap<>();

        public TotemTrackerMod() {
            super("TotemTracker", "Tells you when a player pops a totem.", Category.PLAYER);
            inst = this;
        }

        public static void onPop(Entity e) {
            if (inst == null || !inst.enabled || !(e instanceof PlayerEntity p)) return;
            String name = p.getName().getString();
            int n = inst.pops.merge(name, 1, Integer::sum);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (inst.chat.value) say(mc, "\u00a7e" + name + " \u00a77popped a totem \u00a78(" + n + ")");
            if (inst.toast.value) Notifier.push(name, "Totem popped (" + n + ")", 0xFFFFD84D);
        }
    }

    // ================================================================ STREAMER MODE
    public static final class StreamerModeMod extends Module {
        final Setting.Bool hideCoords = add(new Setting.Bool("Hide coordinates", true));
        final Setting.Bool hideNick = add(new Setting.Bool("Hide my nick", true));
        final Setting.Bool hideServer = add(new Setting.Bool("Hide server address", true));
        static StreamerModeMod inst;

        public StreamerModeMod() {
            super("StreamerMode", "Hides coordinates, nick and server address in Gordey's HUD.", Category.PLAYER);
            inst = this;
        }

        public static boolean coords() { return inst != null && inst.enabled && inst.hideCoords.value; }
        public static boolean nick() { return inst != null && inst.enabled && inst.hideNick.value; }
        public static boolean server() { return inst != null && inst.enabled && inst.hideServer.value; }
    }

    // ================================================================ PVP SAFE
    public static final class PvpSafeMod extends Module {
        final Setting.Num seconds = add(new Setting.Num("PvP lock (s)", 10, 3, 30, 1));

        public PvpSafeMod() {
            super("PvpSafe", "Blocks the Disconnect button for a few seconds after PvP.", Category.PLAYER);
        }
    }

    // ================================================================ SOUND CONTROLLER
    public static final class SoundControllerMod extends Module {
        final Setting.Num crit = add(new Setting.Num("Crit volume %", 30, 0, 100, 5));
        final Setting.Num hits = add(new Setting.Num("Hit volume %", 50, 0, 100, 5));
        final Setting.Num hurt = add(new Setting.Num("Hurt volume %", 60, 0, 100, 5));
        final Setting.Num arrow = add(new Setting.Num("Arrow hit volume %", 70, 0, 100, 5));
        final Setting.Num xp = add(new Setting.Num("XP pickup volume %", 40, 0, 100, 5));
        static SoundControllerMod inst;

        public SoundControllerMod() {
            super("SoundController", "Lowers the volume of common combat sounds.", Category.PLAYER);
            inst = this;
        }

        public static boolean handle(SoundInstance s) {
            if (inst == null || !inst.enabled) return false;
            Identifier id = s.getId();
            String p = id.getPath();
            float f = 1f;
            if (p.contains("player.attack.crit")) f = inst.crit.asFloat() / 100f;
            else if (p.contains("player.attack")) f = inst.hits.asFloat() / 100f;
            else if (p.contains("player.hurt")) f = inst.hurt.asFloat() / 100f;
            else if (p.contains("arrow.hit")) f = inst.arrow.asFloat() / 100f;
            else if (p.contains("experience_orb.pickup")) f = inst.xp.asFloat() / 100f;
            if (f >= 0.999f) return false;
            if (f <= 0.02f) return true;
            try {
                ((SoundInstanceAccessor) s).gordey$setVolume(s.getVolume() * f);
                return false;
            } catch (Throwable t) {
                return f < 0.5f;
            }
        }
    }

    // ================================================================ AUTO RESPAWN
    public static final class AutoRespawnMod extends Module {
        final Setting.Num delay = add(new Setting.Num("Delay (ticks)", 10, 0, 60, 1));
        final Setting.Text command = add(new Setting.Text("Command after respawn", "", 40));
        final Setting.Num cmdDelay = add(new Setting.Num("Command delay (ticks)", 20, 5, 100, 5));
        private int ticks, pending;
        private boolean wasDead;

        public AutoRespawnMod() { super("AutoRespawn", "Respawns automatically and can run a command afterwards.", Category.PLAYER); }

        @Override
        public void onTick(MinecraftClient mc) {
            boolean dead = mc.currentScreen instanceof DeathScreen;
            if (dead) {
                if (++ticks >= delay.asInt()) {
                    mc.player.requestRespawn();
                    mc.setScreen(null);
                    ticks = 0;
                }
            } else ticks = 0;
            if (wasDead && !dead) pending = cmdDelay.asInt();
            wasDead = dead;
            if (pending > 0 && --pending == 0) {
                String c = command.value.trim();
                if (!c.isEmpty()) {
                    if (c.startsWith("/")) c = c.substring(1);
                    mc.player.networkHandler.sendChatCommand(c);
                }
            }
        }
    }
}

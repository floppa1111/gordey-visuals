package gordey.visuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;

import java.util.Locale;
import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    public BooleanSupplier visible = () -> true;

    protected Setting(String name) { this.name = name; }

    public abstract JsonElement save();
    public abstract void load(JsonElement e);

    public static final class Bool extends Setting {
        public boolean value;
        public Bool(String name, boolean def) { super(name); this.value = def; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { value = e.getAsBoolean(); }
    }

    public static final class Num extends Setting {
        public double value, min, max, step;
        public Num(String name, double def, double min, double max, double step) {
            super(name); this.value = def; this.min = min; this.max = max; this.step = step;
        }
        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            if (step > 0) v = Math.round(v / step) * step;
            value = v;
        }
        public int asInt() { return (int) Math.round(value); }
        public float asFloat() { return (float) value; }
        public String display() { return step >= 1 ? String.valueOf(asInt()) : String.format(Locale.ROOT, "%.1f", value); }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { set(e.getAsDouble()); }
    }

    public static final class Mode extends Setting {
        public int index;
        public final String[] modes;
        public Mode(String name, int def, String... modes) { super(name); this.index = def; this.modes = modes; }
        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equals(s); }
        public void next(int d) { index = ((index + d) % modes.length + modes.length) % modes.length; }
        @Override public JsonElement save() { return new JsonPrimitive(index); }
        @Override public void load(JsonElement e) { index = Math.max(0, Math.min(modes.length - 1, e.getAsInt())); }
    }

    public static final class Col extends Setting {
        public float h, s, b;
        public Col(String name, float h, float s, float b) { super(name); this.h = h; this.s = s; this.b = b; }
        public int rgb() { return java.awt.Color.HSBtoRGB(h, s, b) & 0xFFFFFF; }
        @Override public JsonElement save() {
            JsonArray a = new JsonArray();
            a.add(h); a.add(s); a.add(b);
            return a;
        }
        @Override public void load(JsonElement e) {
            JsonArray a = e.getAsJsonArray();
            h = a.get(0).getAsFloat(); s = a.get(1).getAsFloat(); b = a.get(2).getAsFloat();
        }
    }

    public static final class Text extends Setting {
        public String value;
        public final int max;
        public Text(String name, String def, int max) { super(name); this.value = def; this.max = max; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) { value = e.getAsString(); }
    }

    public static final class Data extends Setting {
        public JsonElement value = JsonNull.INSTANCE;
        public Data(String name) { super(name); visible = () -> false; }
        @Override public JsonElement save() { return value == null ? JsonNull.INSTANCE : value; }
        @Override public void load(JsonElement e) { value = e.deepCopy(); }
    }

    public static final class Action extends Setting {
        public final Runnable run;
        public Action(String name, Runnable run) { super(name); this.run = run; }
        @Override public JsonElement save() { return JsonNull.INSTANCE; }
        @Override public void load(JsonElement e) { }
    }
}

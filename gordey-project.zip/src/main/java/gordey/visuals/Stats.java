package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public final class Stats {
    private Stats() { }

    public static double bps, distance;
    public static int deaths;
    public static boolean justDied;
    public static int deathX, deathY, deathZ;
    public static String deathDim = "";
    public static final long sessionStart = System.currentTimeMillis();

    private static double lastX, lastZ;
    private static boolean hasLast, wasDead;

    public static final Deque<Long> leftClicks = new ArrayDeque<>();
    public static final Deque<Long> rightClicks = new ArrayDeque<>();
    public static boolean lDown, rDown;

    public static LivingEntity lastTarget;
    public static long lastHitMs, comboMs;
    public static int combo, hits;
    public static boolean justJoined;
    public static long pvpMs;

    public static boolean inPvp(int seconds) { return pvpMs != 0 && System.currentTimeMillis() - pvpMs < seconds * 1000L; }
    public static long pvpLeft(int seconds) { return Math.max(0, seconds - (System.currentTimeMillis() - pvpMs) / 1000L); }

    public static void onAttack(LivingEntity e) {
        long now = System.currentTimeMillis();
        if (e == lastTarget && now - comboMs < 3000) combo++; else combo = 1;
        hits++;
        lastTarget = e; lastHitMs = now; comboMs = now;
        if (e instanceof PlayerEntity) pvpMs = now;
    }

    public static void reset() { hasLast = false; wasDead = false; justDied = false; bps = 0; }

    public static void tick(MinecraftClient mc) {
        double px = mc.player.getX(), pz = mc.player.getZ();
        if (hasLast) {
            double d = Math.sqrt((px - lastX) * (px - lastX) + (pz - lastZ) * (pz - lastZ));
            if (d < 10) { bps = bps * 0.75 + d * 20.0 * 0.25; distance += d; }
        }
        lastX = px; lastZ = pz; hasLast = true;

        if (mc.player.hurtTime > 0 && mc.player.getAttacker() instanceof PlayerEntity) pvpMs = System.currentTimeMillis();

        boolean dead = mc.currentScreen instanceof DeathScreen;
        justDied = dead && !wasDead;
        if (justDied) {
            deaths++;
            deathX = mc.player.getBlockX(); deathY = mc.player.getBlockY(); deathZ = mc.player.getBlockZ();
            deathDim = mc.world != null ? mc.world.getRegistryKey().getValue().getPath() : "";
        }
        wasDead = dead;
    }

    public static void pollMouse(MinecraftClient mc) {
        long hd = mc.getWindow().getHandle();
        boolean free = mc.currentScreen == null;
        boolean l = free && GLFW.glfwGetMouseButton(hd, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = free && GLFW.glfwGetMouseButton(hd, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (l && !lDown) leftClicks.addLast(now);
        if (r && !rDown) rightClicks.addLast(now);
        lDown = l; rDown = r;
        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.pollFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.pollFirst();
    }
}

package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Text styles: gradient, glow, spaced caps, rainbow, outline. */
public final class TextFx {
    private TextFx() { }

    public static final String[] NAMES = {"Normal", "Gradient", "Glow", "Spaced", "Rainbow", "Outline"};

    private static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }

    public static int width(String s, String style) {
        TextRenderer t = tr();
        if (style.equals("Spaced") || style.equals("Fancy")) {
            String u = s.toUpperCase();
            int w = 0;
            for (int i = 0; i < u.length(); i++) w += t.getWidth(String.valueOf(u.charAt(i))) + 1;
            return Math.max(0, w - 1);
        }
        return t.getWidth(s);
    }

    private static int perChar(DrawContext ctx, TextRenderer t, String s, int x, int y, int mode, boolean spaced, int c0, int c1, boolean shadow) {
        String u = spaced ? s.toUpperCase() : s;
        int cx = x, n = u.length();
        long now = System.currentTimeMillis();
        for (int i = 0; i < n; i++) {
            String cs = String.valueOf(u.charAt(i));
            float f = n > 1 ? i / (float) (n - 1) : 0f;
            int col = mode == 1 ? (0xFF000000 | java.awt.Color.HSBtoRGB(((now / 1500f) + i * 0.06f) % 1f, 0.65f, 1f)) : Gfx.lerp(c0, c1, f);
            ctx.drawText(t, cs, cx, y, col, shadow);
            cx += t.getWidth(cs) + (spaced ? 1 : 0);
        }
        return cx - x - (spaced && n > 0 ? 1 : 0);
    }

    public static int draw(DrawContext ctx, String s, int x, int y, int color, String style, int ac, int ac2) {
        TextRenderer t = tr();
        switch (style) {
            case "Gradient": return perChar(ctx, t, s, x, y, 0, false, ac, ac2, true);
            case "Rainbow": return perChar(ctx, t, s, x, y, 1, false, 0, 0, true);
            case "Spaced": return perChar(ctx, t, s, x, y, 0, true, color, color, true);
            case "Glow": {
                int g = Gfx.alpha(ac, 85);
                ctx.drawText(t, s, x - 1, y, g, false); ctx.drawText(t, s, x + 1, y, g, false);
                ctx.drawText(t, s, x, y - 1, g, false); ctx.drawText(t, s, x, y + 1, g, false);
                ctx.drawText(t, s, x, y, color, true);
                return t.getWidth(s);
            }
            case "Outline": {
                ctx.drawText(t, s, x - 1, y, 0xFF000000, false); ctx.drawText(t, s, x + 1, y, 0xFF000000, false);
                ctx.drawText(t, s, x, y - 1, 0xFF000000, false); ctx.drawText(t, s, x, y + 1, 0xFF000000, false);
                ctx.drawText(t, s, x, y, color, false);
                return t.getWidth(s);
            }
            case "Fancy": {
                int g = Gfx.alpha(ac, 70);
                perChar(ctx, t, s, x - 1, y, 0, true, g, g, false);
                perChar(ctx, t, s, x + 1, y, 0, true, g, g, false);
                perChar(ctx, t, s, x, y - 1, 0, true, g, g, false);
                perChar(ctx, t, s, x, y + 1, 0, true, g, g, false);
                return perChar(ctx, t, s, x, y, 0, true, ac, ac2, true);
            }
            default:
                ctx.drawText(t, s, x, y, color, true);
                return t.getWidth(s);
        }
    }
}

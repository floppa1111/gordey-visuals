package gordey.visuals;

public final class Theme {
    private Theme() { }

    public static Setting.Mode preset;
    public static Setting.Col custom;

    private static final int[] COLORS = {0xFF7A00, 0x965AFF, 0x00C8FF, 0x28E696, 0xFF468C};

    public static int accent() {
        if (preset == null) return 0xFFFF7A00;
        int i = preset.index;
        if (i < COLORS.length) return 0xFF000000 | COLORS[i];
        if (preset.is("Rainbow")) return 0xFF000000 | java.awt.Color.HSBtoRGB((System.currentTimeMillis() % 6000L) / 6000f, 0.7f, 1f);
        return 0xFF000000 | custom.rgb();
    }

    public static int accent2() { return shift(accent(), 0.09f); }

    public static int shift(int argb, float dh) {
        float[] hsb = java.awt.Color.RGBtoHSB((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, null);
        float h = hsb[0] + dh;
        h -= (float) Math.floor(h);
        return 0xFF000000 | java.awt.Color.HSBtoRGB(h, hsb[1], hsb[2]);
    }
}

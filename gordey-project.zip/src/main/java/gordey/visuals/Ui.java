package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Redesigned HUD modules with icons, gradients and text styles. */
public final class Ui {
    private Ui() { }

    static String armorSet(MinecraftClient mc) {
        Map<String, Integer> cnt = new HashMap<>();
        EquipmentSlot[] slots = {EquipmentSlot.CHEST, EquipmentSlot.HEAD, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        String first = null;
        for (EquipmentSlot s : slots) {
            ItemStack st = mc.player.getEquippedStack(s);
            if (st.isEmpty()) continue;
            String p = Player.path(st);
            String k = null;
            if (p.startsWith("leather_")) k = "leather";
            else if (p.startsWith("chainmail_")) k = "chainmail";
            else if (p.startsWith("iron_")) k = "iron";
            else if (p.startsWith("golden_")) k = "golden";
            else if (p.startsWith("diamond_")) k = "diamond";
            else if (p.startsWith("netherite_")) k = "netherite";
            else if (p.startsWith("copper_")) k = "copper";
            if (k == null) continue;
            if (first == null) first = k;
            cnt.merge(k, 1, Integer::sum);
        }
        if (cnt.isEmpty()) return "none";
        String best = first;
        for (Map.Entry<String, Integer> e : cnt.entrySet()) if (e.getValue() > cnt.get(best)) best = e.getKey();
        return best;
    }

    // ================================================================ PLAYER STATS (icons)
    public static final class PlayerStatsMod extends HudModule {
        final Setting.Bool showHealth = add(new Setting.Bool("Health", true));
        final Setting.Bool showFood = add(new Setting.Bool("Food", true));
        final Setting.Bool showArmor = add(new Setting.Bool("Armor", true));
        final Setting.Bool showXp = add(new Setting.Bool("XP level", true));
        final Setting.Bool icons = add(new Setting.Bool("Icons", true));
        final Setting.Bool gradient = add(new Setting.Bool("Gradient bars", true));
        final Setting.Bool numbers = add(new Setting.Bool("Numbers", true));

        public PlayerStatsMod() { super("PlayerStats", "Health, food, armor and XP with pixel icons."); }
        @Override protected int defaultX(int sw) { return sw - 134; }
        @Override protected int defaultY(int sh) { return sh / 2 + 30; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            var p = mc.player;
            List<Object[]> rows = new ArrayList<>();
            if (showHealth.value) rows.add(new Object[]{0, Extra.f1(p.getHealth()), Math.min(1f, p.getHealth() / Math.max(1f, p.getMaxHealth())), 0xFFE03A3A});
            if (showFood.value) rows.add(new Object[]{1, String.valueOf(p.getHungerManager().getFoodLevel()), p.getHungerManager().getFoodLevel() / 20f, 0xFFE8932B});
            if (showArmor.value) rows.add(new Object[]{2, String.valueOf(p.getArmor()), Math.min(1f, p.getArmor() / 20f), 0xFFB4C8E6});
            if (showXp.value) rows.add(new Object[]{3, String.valueOf(p.experienceLevel), p.experienceProgress, 0xFF7CFF4D});
            if (rows.isEmpty()) { w = 0; h = 0; return; }
            String set = showArmor.value ? armorSet(mc) : "none";
            int pad = 6, rowH = 15, iconW = icons.value ? 16 : 0, barW = 78;
            int valW = 0;
            for (Object[] r : rows) valW = Math.max(valW, numbers.value ? fxWidth((String) r[1]) : 0);
            int cw = pad * 2 + iconW + barW + (numbers.value ? valW + 6 : 0);
            int ch = rows.size() * rowH + pad * 2 - 3;
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            for (int i = 0; i < rows.size(); i++) {
                Object[] r = rows.get(i);
                int kind = (Integer) r[0];
                int col = (Integer) r[3];
                float ratio = Math.max(0f, Math.min(1f, (Float) r[2]));
                int iy = py + pad - 1 + i * rowH;
                int ix = px + pad;
                if (icons.value) {
                    switch (kind) {
                        case 0 -> Icons.draw(ctx, Icons.HEART, ix, iy + 1, 11, 10);
                        case 1 -> Icons.draw(ctx, Icons.FOOD, ix, iy, 11, 11);
                        case 2 -> Icons.draw(ctx, Icons.ARMOR.get(set), ix - 1, iy, 13, 12);
                        default -> Icons.draw(ctx, Icons.BOTTLE, ix + 1, iy - 1, 9, 12);
                    }
                }
                int bx = ix + iconW, by = iy + 4;
                Gfx.round(ctx, bx, by, barW, 5, 2, 0xFF1A1A22);
                int fw = Math.round(barW * ratio);
                if (fw > 0) {
                    if (gradient.value) {
                        int dark = Gfx.lerp(col, 0xFF000000, 0.5f);
                        for (int k = 0; k < fw; k += 2) ctx.fill(bx + k, by, bx + Math.min(k + 2, fw), by + 5, Gfx.lerp(dark, col, k / (float) Math.max(1, barW)));
                    } else Gfx.round(ctx, bx, by, fw, 5, 2, col);
                }
                if (numbers.value) fx(ctx, (String) r[1], bx + barW + 5, iy + 2, 0xFFFFFFFF);
            }
        }
    }

    // ================================================================ CLOCK
    public static final class ClockMod extends HudModule {
        final Setting.Mode look = add(new Setting.Mode("Look", 1, "Normal", "Fancy", "Minimal"));
        final Setting.Bool seconds = add(new Setting.Bool("Seconds", true));
        final Setting.Bool date = add(new Setting.Bool("Date", true));
        final Setting.Bool h24 = add(new Setting.Bool("24-hour", true));

        public ClockMod() { super("Clock", "Real time with fancy or plain text."); }
        @Override protected int defaultX(int sw) { return sw / 2 - 40; }
        @Override protected int defaultY(int sh) { return 32; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            String pattern = (h24.value ? "HH" : "hh") + ":mm" + (seconds.value ? ":ss" : "") + (h24.value ? "" : " a");
            String time = LocalTime.now().format(DateTimeFormatter.ofPattern(pattern, Locale.ENGLISH));
            String d = LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            boolean fancy = look.is("Fancy"), minimal = look.is("Minimal");
            String style = fancy ? "Fancy" : (minimal ? "Normal" : styleName());
            int tw = TextFx.width(time, style);
            boolean showDate = date.value && !minimal;
            int cw = Math.max(tw, showDate ? tr.getWidth(d) : 0) + (minimal ? 12 : 22);
            int ch = (minimal ? 14 : 16) + (showDate ? 11 : 0) + (fancy ? 3 : 0);
            w = cw; h = ch;
            int px = left(), py = y;
            if (minimal) {
                Gfx.round(ctx, px, py, cw, ch, rounding.asInt(), bgColor());
            } else panel(ctx, px, py, cw, ch);
            int ac = accent(), ac2 = accent2();
            TextFx.draw(ctx, time, px + (cw - tw) / 2, py + (minimal ? 3 : 5), 0xFFFFFFFF, style, ac, ac2);
            if (fancy) {
                int lw = cw - 20;
                for (int i = 0; i < lw; i += 2) ctx.fill(px + 10 + i, py + 15, px + 10 + Math.min(i + 2, lw), py + 16, Gfx.lerp(ac, ac2, i / (float) lw));
            }
            if (showDate) Gfx.centered(ctx, d, px + cw / 2, py + (fancy ? 19 : 17), ac);
        }
    }

    // ================================================================ FPS GRAPH
    public static final class FpsGraphMod extends HudModule {
        final Setting.Mode graph = add(new Setting.Mode("Graph", 1, "Line", "Area", "Bars", "Off"));
        final Setting.Num width = add(new Setting.Num("Width", 110, 60, 220, 10));
        final Setting.Num height = add(new Setting.Num("Height", 28, 14, 60, 2));
        final Setting.Bool refLine = add(new Setting.Bool("60 FPS line", true));
        final Setting.Bool byPerf = add(new Setting.Bool("Color by FPS", true));
        final Setting.Bool stats = add(new Setting.Bool("Min / avg / max", true));
        private final float[] hist = new float[100];
        private long last;

        public FpsGraphMod() { super("FpsGraph", "FPS counter with a clear performance graph."); }
        @Override protected int defaultY(int sh) { return sh / 2 + 70; }

        private int perf(float fps) { return Extra.healthColor(Math.min(1f, fps / 70f)); }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            TextRenderer tr = mc.textRenderer;
            long now = System.currentTimeMillis();
            if (now - last >= 40) {
                System.arraycopy(hist, 1, hist, 0, hist.length - 1);
                hist[hist.length - 1] = mc.getCurrentFps();
                last = now;
            }
            int fps = mc.getCurrentFps();
            boolean showGraph = !graph.is("Off");
            int gw = width.asInt(), gh = height.asInt(), pad = 5;
            int cw = gw + pad * 2;
            int ch = pad * 2 + 12 + (showGraph ? gh + 3 : 0) + (stats.value ? 10 : 0);
            w = cw; h = ch;
            int px = left(), py = y;
            panel(ctx, px, py, cw, ch);
            int ac = accent();
            int main = byPerf.value ? perf(fps) : ac;
            String num = String.valueOf(fps);
            int nw = fx(ctx, num, px + pad + 2, py + pad, main);
            ctx.drawText(tr, "FPS", px + pad + 2 + nw + 3, py + pad, 0xFF9A9AA6, false);
            String ft = String.format(Locale.ROOT, "%.1f ms", fps > 0 ? 1000f / fps : 0f);
            ctx.drawText(tr, ft, px + cw - pad - tr.getWidth(ft), py + pad, 0xFF9A9AA6, false);

            int gy = py + pad + 13;
            float mx = 70, mn = Float.MAX_VALUE, sum = 0; int cnt = 0;
            for (float f : hist) { if (f <= 0) continue; mx = Math.max(mx, f * 1.08f); mn = Math.min(mn, f); sum += f; cnt++; }
            if (showGraph) {
                int gx = px + pad;
                Gfx.round(ctx, gx, gy, gw, gh, 2, 0x55000000);
                if (refLine.value) {
                    int y60 = gy + gh - Math.round(60f / mx * gh);
                    for (int x = gx; x < gx + gw; x += 4) ctx.fill(x, y60, x + 2, y60 + 1, 0x66FFFFFF);
                }
                int n = hist.length;
                float step = gw / (float) (n - 1);
                if (graph.is("Bars")) {
                    for (int i = 0; i < n; i++) {
                        if (hist[i] <= 0) continue;
                        int bh = Math.max(1, Math.round(hist[i] / mx * gh));
                        int bx = gx + Math.round(i * step);
                        ctx.fill(bx, gy + gh - bh, bx + Math.max(1, Math.round(step)), gy + gh, byPerf.value ? perf(hist[i]) : ac);
                    }
                } else {
                    int[] ys = new int[n];
                    for (int i = 0; i < n; i++) ys[i] = gy + gh - Math.max(0, Math.min(gh, Math.round(hist[i] / mx * gh)));
                    if (graph.is("Area")) {
                        for (int x = 0; x < gw; x++) {
                            float pos = x / step;
                            int i = Math.min(n - 2, (int) pos);
                            float fr = pos - i;
                            int yy = Math.round(ys[i] + (ys[i + 1] - ys[i]) * fr);
                            float v = hist[i] + (hist[i + 1] - hist[i]) * fr;
                            ctx.fill(gx + x, yy, gx + x + 1, gy + gh, Gfx.alpha(byPerf.value ? perf(v) : ac, 60));
                        }
                    }
                    for (int i = 0; i < n - 1; i++) {
                        if (hist[i] <= 0 || hist[i + 1] <= 0) continue;
                        Gfx.line(ctx, gx + Math.round(i * step), ys[i], gx + Math.round((i + 1) * step), ys[i + 1], byPerf.value ? (0xFF000000 | perf(hist[i + 1])) : ac, 1);
                    }
                }
            }
            if (stats.value && cnt > 0) {
                int sy = py + ch - pad - 8;
                ctx.drawText(tr, "min " + Math.round(mn), px + pad + 2, sy, 0xFF8E8E9A, false);
                String a = "avg " + Math.round(sum / cnt);
                ctx.drawText(tr, a, px + (cw - tr.getWidth(a)) / 2, sy, 0xFF8E8E9A, false);
                String m2 = "max " + Math.round(mx / 1.08f);
                ctx.drawText(tr, m2, px + cw - pad - 2 - tr.getWidth(m2), sy, 0xFF8E8E9A, false);
            }
        }
    }

    // ================================================================ MODULE LIST
    public static final class ModuleListMod extends HudModule {
        final Setting.Mode order = add(new Setting.Mode("Order", 0, "Length", "A-Z"));
        final Setting.Mode bar = add(new Setting.Mode("Bar", 0, "Right", "Left", "None"));
        final Setting.Mode colorMode = add(new Setting.Mode("Colors", 0, "Gradient", "Solid", "Rainbow", "Wave"));
        final Setting.Bool background = add(new Setting.Bool("Background", true));
        final Setting.Num padding = add(new Setting.Num("Padding", 1, 0, 4, 1));

        public ModuleListMod() {
            super("ModuleList", "List of enabled modules (many looks).");
            anchorRight = true;
            style.remove(effect);
            style.remove(rounding);
            enabled = true;
        }

        @Override protected int defaultX(int sw) { return sw - 6; }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            List<Module> list = new ArrayList<>();
            for (Module m : ModuleManager.ALL) if (m.enabled && !(m instanceof Mods.InterfaceMod) && !(m instanceof ModuleListMod)) list.add(m);
            if (list.isEmpty()) { w = 0; h = 0; return; }
            String st = styleName();
            if (order.is("A-Z")) list.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
            else list.sort((a, b) -> Integer.compare(TextFx.width(b.name, st), TextFx.width(a.name, st)));
            int pad = padding.asInt(), rowH = 11 + pad * 2;
            int maxW = 0;
            for (Module m : list) maxW = Math.max(maxW, TextFx.width(m.name, st));
            w = maxW + 10; h = list.size() * rowH;
            int right = x;
            int ac = accent(), ac2 = accent2();
            long now = System.currentTimeMillis();
            for (int i = 0; i < list.size(); i++) {
                Module m = list.get(i);
                int tw = TextFx.width(m.name, st);
                int ry = y + i * rowH;
                float f = list.size() > 1 ? i / (float) (list.size() - 1) : 0f;
                int col;
                switch (colorMode.get()) {
                    case "Solid" -> col = ac;
                    case "Rainbow" -> col = 0xFF000000 | java.awt.Color.HSBtoRGB(((now / 3000f) + i * 0.07f) % 1f, 0.65f, 1f);
                    case "Wave" -> col = Gfx.lerp(ac, ac2, (float) (0.5 + 0.5 * Math.sin(now / 500.0 + i * 0.6)));
                    default -> col = Gfx.lerp(ac, ac2, f);
                }
                int barW = bar.is("None") ? 0 : 2;
                int textRight = right - barW - 3;
                if (background.value) ctx.fill(textRight - tw - 4, ry, right - (bar.is("Right") ? 0 : 0), ry + rowH, bgColor());
                if (bar.is("Right")) ctx.fill(right - 2, ry, right, ry + rowH, col);
                else if (bar.is("Left")) ctx.fill(textRight - tw - 4, ry, textRight - tw - 2, ry + rowH, col);
                TextFx.draw(ctx, m.name, textRight - tw, ry + pad + 2, col, st, col, Theme.shift(col, 0.08f));
            }
        }
    }
}

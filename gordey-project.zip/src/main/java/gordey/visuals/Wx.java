package gordey.visuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/** World-space visuals drawn through a software camera projection. */
public final class Wx {
    private Wx() { }

    private static double rnd(double a, double b) { return a + ThreadLocalRandom.current().nextDouble() * (b - a); }

    private static boolean solid(MinecraftClient mc, double x, double y, double z) {
        BlockPos bp = BlockPos.ofFloored(x, y, z);
        return !mc.world.getBlockState(bp).getCollisionShape(mc.world, bp).isEmpty();
    }

    private static boolean blockedFromCamera(MinecraftClient mc, double x, double y, double z) {
        for (int i = 1; i <= 3; i++) {
            double t = i / 4.0;
            if (solid(mc, CameraFx.camX + (x - CameraFx.camX) * t, CameraFx.camY + (y - CameraFx.camY) * t, CameraFx.camZ + (z - CameraFx.camZ) * t)) return true;
        }
        return false;
    }

    // ================================================================ FLOATERS
    public static final class FloatersMod extends HudModule {
        final Setting.Mode kind = add(new Setting.Mode("Shape", 5, "Cubes", "Diamonds", "Lanterns", "Orbs", "Hearts", "Mixed"));
        final Setting.Num count = add(new Setting.Num("Count", 35, 5, 120, 5));
        final Setting.Num radius = add(new Setting.Num("Radius", 16, 6, 32, 1));
        final Setting.Num size = add(new Setting.Num("Size", 0.55, 0.2, 1.6, 0.05));
        final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.2, 3.0, 0.1));
        final Setting.Mode colorMode = add(new Setting.Mode("Color", 1, "Theme", "Gradient", "Custom", "Rainbow", "Random"));
        final Setting.Col custom = add(new Setting.Col("Custom color", 0.58f, 0.7f, 1f));
        final Setting.Bool glow = add(new Setting.Bool("Glow", true));
        final Setting.Num thick = add(new Setting.Num("Line thickness", 1, 1, 2, 1));
        final Setting.Bool spin = add(new Setting.Bool("Rotate", true));

        private static final class O {
            double x, y, z, vx, vy, vz;
            float age, life, rot, rs, size, depth, sx, sy;
            int kind, rgb;
        }

        private final List<O> objs = new ArrayList<>();
        private long lastNs;

        public FloatersMod() {
            super("Floaters", "Transparent outlined cubes, lanterns, orbs and hearts floating in the world.");
            style.clear();
            backdrop = true;
            custom.visible = () -> colorMode.is("Custom");
        }

        private int pickColor() {
            long now = System.currentTimeMillis();
            switch (colorMode.get()) {
                case "Gradient": return Gfx.lerp(Theme.accent(), Theme.accent2(), (float) Math.random()) & 0xFFFFFF;
                case "Custom": return custom.rgb();
                case "Rainbow": return java.awt.Color.HSBtoRGB((now % 5000L) / 5000f, 0.7f, 1f) & 0xFFFFFF;
                case "Random": return java.awt.Color.HSBtoRGB((float) Math.random(), 0.65f, 1f) & 0xFFFFFF;
                default: return Theme.accent() & 0xFFFFFF;
            }
        }

        private void spawn(MinecraftClient mc, double px, double py, double pz) {
            double a = rnd(0, Math.PI * 2), r = radius.value * Math.sqrt(ThreadLocalRandom.current().nextDouble());
            O o = new O();
            o.x = px + Math.cos(a) * r; o.z = pz + Math.sin(a) * r; o.y = py + rnd(-0.5, 7);
            if (solid(mc, o.x, o.y, o.z)) return;
            o.kind = kind.index < 5 ? kind.index : ThreadLocalRandom.current().nextInt(5);
            o.size = (float) (size.value * rnd(0.7, 1.3));
            o.life = (float) rnd(10, 20);
            o.rot = (float) rnd(0, 6.28);
            o.rs = spin.value ? (float) rnd(-1.0, 1.0) : 0f;
            switch (o.kind) {
                case 2 -> { o.vy = rnd(0.25, 0.55); o.vx = rnd(-0.12, 0.12); o.vz = rnd(-0.12, 0.12); }
                case 3 -> { o.vx = rnd(-0.25, 0.25); o.vy = rnd(-0.15, 0.25); o.vz = rnd(-0.25, 0.25); }
                case 4 -> { o.vy = rnd(0.3, 0.6); o.vx = rnd(-0.08, 0.08); o.vz = rnd(-0.08, 0.08); }
                default -> { o.vx = rnd(-0.2, 0.2); o.vy = rnd(-0.05, 0.2); o.vz = rnd(-0.2, 0.2); }
            }
            o.rgb = pickColor();
            objs.add(o);
        }

        private int ac(int rgb, float a) { return Gfx.alpha(rgb, (int) (255 * Math.max(0f, Math.min(1f, a)))); }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            if (!CameraFx.cameraFresh()) return;
            long ns = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
            lastNs = ns;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
            double R = radius.value, sp = speed.value;
            for (int tries = 0; tries < 6 && objs.size() < count.asInt(); tries++) spawn(mc, px, py, pz);
            while (objs.size() > count.asInt()) objs.remove(objs.size() - 1);

            List<O> vis = new ArrayList<>();
            float[] p = new float[3];
            for (Iterator<O> it = objs.iterator(); it.hasNext(); ) {
                O o = it.next();
                o.age += dt;
                o.x += o.vx * dt * sp; o.y += o.vy * dt * sp; o.z += o.vz * dt * sp;
                o.rot += o.rs * dt;
                double dx = o.x - px, dz = o.z - pz;
                if (o.age > o.life || dx * dx + dz * dz > R * R * 1.9) { it.remove(); continue; }
                if (!CameraFx.project(o.x, o.y, o.z, sw, sh, p)) continue;
                if (p[0] < -150 || p[0] > sw + 150 || p[1] < -150 || p[1] > sh + 150) continue;
                o.depth = p[2]; o.sx = p[0]; o.sy = p[1];
                vis.add(o);
            }
            vis.sort(Comparator.comparingDouble((O o) -> -o.depth));
            for (O o : vis) {
                if (blockedFromCamera(mc, o.x, o.y, o.z)) continue;
                float a = Math.min(1f, o.age / 1.5f) * Math.min(1f, (o.life - o.age) / 1.5f);
                a *= (float) Math.max(0.2, Math.min(1.0, 1.6 - o.depth / (R * 0.9)));
                if (a <= 0.02f) continue;
                double ppb = CameraFx.pxPerBlock(o.depth, sh);
                switch (o.kind) {
                    case 0 -> cube(ctx, o, a, sw, sh);
                    case 1 -> diamond(ctx, o, a, sw, sh);
                    case 2 -> lantern(ctx, o.sx, o.sy, o.size * 1.5 * ppb, o.rgb, a);
                    case 3 -> orb(ctx, o.sx, o.sy, o.size * 0.5 * ppb, o.rgb, a);
                    default -> {
                        int s = (int) Math.max(7, o.size * 1.2 * ppb);
                        Icons.drawTinted(ctx, Icons.HEART, (int) o.sx - s / 2, (int) o.sy - s / 2, s, s * 10 / 11, o.rgb, a);
                    }
                }
            }
        }

        private void edge(DrawContext ctx, float[] ax, float[] ay, int i, int j, int rgb, float a) {
            int t = thick.asInt();
            if (glow.value) Gfx.line(ctx, (int) ax[i], (int) ay[i], (int) ax[j], (int) ay[j], ac(rgb, a * 0.18f), t + 2);
            Gfx.line(ctx, (int) ax[i], (int) ay[i], (int) ax[j], (int) ay[j], ac(rgb, a), t);
        }

        private void cube(DrawContext ctx, O o, float a, int sw, int sh) {
            double hs = o.size / 2.0;
            double ca = Math.cos(o.rot), sa = Math.sin(o.rot), cb = Math.cos(o.rot * 0.6), sb = Math.sin(o.rot * 0.6);
            float[] xs = new float[8], ys = new float[8], p = new float[3];
            for (int c = 0; c < 8; c++) {
                double lx = (c & 1) == 0 ? -hs : hs, ly = (c & 2) == 0 ? -hs : hs, lz = (c & 4) == 0 ? -hs : hs;
                double x1 = lx * ca + lz * sa, z1 = -lx * sa + lz * ca;
                double y2 = ly * cb - z1 * sb, z2 = ly * sb + z1 * cb;
                if (!CameraFx.project(o.x + x1, o.y + y2, o.z + z2, sw, sh, p)) return;
                xs[c] = p[0]; ys[c] = p[1];
            }
            for (int c = 0; c < 8; c++) for (int bit = 1; bit <= 4; bit <<= 1) if ((c & bit) == 0) edge(ctx, xs, ys, c, c | bit, o.rgb, a);
        }

        private void diamond(DrawContext ctx, O o, float a, int sw, int sh) {
            double hs = o.size / 2.0;
            double ca = Math.cos(o.rot), sa = Math.sin(o.rot);
            double[][] v = {{hs, 0, 0}, {-hs, 0, 0}, {0, 0, hs}, {0, 0, -hs}, {0, hs * 1.5, 0}, {0, -hs * 1.5, 0}};
            float[] xs = new float[6], ys = new float[6], p = new float[3];
            for (int i = 0; i < 6; i++) {
                double x1 = v[i][0] * ca + v[i][2] * sa, z1 = -v[i][0] * sa + v[i][2] * ca;
                if (!CameraFx.project(o.x + x1, o.y + v[i][1], o.z + z1, sw, sh, p)) return;
                xs[i] = p[0]; ys[i] = p[1];
            }
            for (int pole = 4; pole <= 5; pole++) for (int e = 0; e < 4; e++) edge(ctx, xs, ys, pole, e, o.rgb, a);
            edge(ctx, xs, ys, 0, 2, o.rgb, a); edge(ctx, xs, ys, 2, 1, o.rgb, a);
            edge(ctx, xs, ys, 1, 3, o.rgb, a); edge(ctx, xs, ys, 3, 0, o.rgb, a);
        }

        private void orb(DrawContext ctx, float sx, float sy, double r0, int rgb, float a) {
            int r = (int) Math.max(2, r0), cx = (int) sx, cy = (int) sy;
            Gfx.round(ctx, cx - r * 2, cy - r * 2, r * 4, r * 4, r * 2, ac(rgb, a * 0.10f));
            Gfx.round(ctx, cx - r * 3 / 2, cy - r * 3 / 2, r * 3, r * 3, r * 3 / 2, ac(rgb, a * 0.18f));
            Gfx.round(ctx, cx - r, cy - r, r * 2, r * 2, r, ac(rgb, a * 0.80f));
            int c = Math.max(1, r / 3);
            Gfx.round(ctx, cx - c, cy - c, c * 2, c * 2, c, ac(0xFFFFFF, a * 0.85f));
        }

        private void lantern(DrawContext ctx, float sx, float sy, double hpx, int rgb, float a) {
            int h = (int) Math.max(4, hpx), cx = (int) sx, top = (int) (sy - h / 2.0);
            if (h < 8) { ctx.fill(cx - 1, top, cx + 2, top + h, ac(rgb, a)); return; }
            int bw = (int) (h * 0.8), capH = Math.max(1, h / 8), bodyH = h - capH * 2;
            for (int i = 3; i >= 1; i--) Gfx.round(ctx, cx - bw / 2 - i * 2, top + capH - i * 2, bw + i * 4, bodyH + i * 4, bw / 2, ac(rgb, a * 0.08f * (4 - i)));
            int gold = 0xD8A53B;
            ctx.fill(cx, top + h, cx + 1, top + h + Math.max(2, h / 3), ac(gold, a));
            Gfx.round(ctx, cx - bw / 2, top + capH, bw, bodyH, Math.max(2, bw / 3), ac(rgb, a * 0.92f));
            Gfx.round(ctx, cx - bw / 2 + bw / 5, top + capH + bodyH / 6, bw - bw * 2 / 5, bodyH * 2 / 3, Math.max(1, bw / 4), ac(0xFFE9A8, a * 0.5f));
            int dark = Gfx.lerp(0xFF000000 | rgb, 0xFF000000, 0.45f) & 0xFFFFFF;
            for (int k = -1; k <= 1; k++) ctx.fill(cx + k * bw / 4, top + capH + 1, cx + k * bw / 4 + 1, top + capH + bodyH - 1, ac(dark, a * 0.6f));
            int cw2 = (int) (bw * 0.6);
            ctx.fill(cx - cw2 / 2, top, cx + cw2 / 2, top + capH, ac(gold, a));
            ctx.fill(cx - cw2 / 2, top + h - capH, cx + cw2 / 2, top + h, ac(gold, a));
        }
    }

    // ================================================================ BLOCK OVERLAY
    public static final class BlockOverlayMod extends HudModule {
        final Setting.Mode look = add(new Setting.Mode("Style", 1, "Outline", "Glow", "Filled", "Corners", "Pulse"));
        final Setting.Num thick = add(new Setting.Num("Thickness", 1, 1, 3, 1));
        final Setting.Num alpha = add(new Setting.Num("Opacity", 220, 40, 255, 5));
        final Setting.Num fill = add(new Setting.Num("Fill", 30, 0, 140, 5));

        public BlockOverlayMod() {
            super("BlockOverlay", "Custom outline for the block you look at. Turn off View Bobbing for perfect alignment.");
            style.remove(opacity);
            style.remove(rounding);
            style.remove(effect);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            if (!CameraFx.cameraFresh() || mc.world == null) return;
            if (!(mc.crosshairTarget instanceof BlockHitResult bhr) || bhr.getType() != HitResult.Type.BLOCK) return;
            BlockPos bp = bhr.getBlockPos();
            var shape = mc.world.getBlockState(bp).getOutlineShape(mc.world, bp);
            if (shape.isEmpty()) return;
            Box bb = shape.getBoundingBox();
            double e = 0.003;
            double x0 = bp.getX() + bb.minX - e, x1 = bp.getX() + bb.maxX + e;
            double y0 = bp.getY() + bb.minY - e, y1 = bp.getY() + bb.maxY + e;
            double z0 = bp.getZ() + bb.minZ - e, z1 = bp.getZ() + bb.maxZ + e;
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            float[] xs = new float[8], ys = new float[8], p = new float[3];
            for (int c = 0; c < 8; c++) {
                double x = (c & 1) == 0 ? x0 : x1, y = (c & 2) == 0 ? y0 : y1, z = (c & 4) == 0 ? z0 : z1;
                if (!CameraFx.project(x, y, z, sw, sh, p)) return;
                xs[c] = p[0]; ys[c] = p[1];
            }
            boolean[] fv = {
                    CameraFx.camX < x0, CameraFx.camX > x1,   // -X, +X
                    CameraFx.camY < y0, CameraFx.camY > y1,   // -Y, +Y
                    CameraFx.camZ < z0, CameraFx.camZ > z1    // -Z, +Z
            };
            int rgb = accent() & 0xFFFFFF;
            int a = alpha.asInt();
            if (look.is("Pulse")) a = (int) (a * (0.55 + 0.45 * Math.sin(System.currentTimeMillis() / 220.0)));
            int t = thick.asInt();

            int fa = fill.asInt();
            if (fa > 0 || look.is("Filled")) {
                int[][] faces = {{0, 2, 6, 4}, {1, 3, 7, 5}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 5, 7, 6}};
                int fcol = Gfx.alpha(rgb, look.is("Filled") ? Math.max(fa, 50) : fa);
                for (int f = 0; f < 6; f++) {
                    if (!fv[f]) continue;
                    float[] fx2 = new float[4], fy2 = new float[4];
                    for (int k = 0; k < 4; k++) { fx2[k] = xs[faces[f][k]]; fy2[k] = ys[faces[f][k]]; }
                    Gfx.fillPoly(ctx, fx2, fy2, 4, fcol);
                }
            }
            // edges: [from, to, faceA, faceB]
            for (int c = 0; c < 8; c++) {
                for (int axis = 0; axis < 3; axis++) {
                    int bit = 1 << axis;
                    if ((c & bit) != 0) continue;
                    int d = c | bit;
                    int fa1, fa2;
                    if (axis == 0) { fa1 = (c & 2) == 0 ? 2 : 3; fa2 = (c & 4) == 0 ? 4 : 5; }
                    else if (axis == 1) { fa1 = (c & 1) == 0 ? 0 : 1; fa2 = (c & 4) == 0 ? 4 : 5; }
                    else { fa1 = (c & 1) == 0 ? 0 : 1; fa2 = (c & 2) == 0 ? 2 : 3; }
                    if (!fv[fa1] && !fv[fa2]) continue;
                    int x0i = (int) xs[c], y0i = (int) ys[c], x1i = (int) xs[d], y1i = (int) ys[d];
                    if (look.is("Corners")) {
                        int mx1 = x0i + (x1i - x0i) * 3 / 10, my1 = y0i + (y1i - y0i) * 3 / 10;
                        int mx2 = x1i - (x1i - x0i) * 3 / 10, my2 = y1i - (y1i - y0i) * 3 / 10;
                        Gfx.line(ctx, x0i, y0i, mx1, my1, Gfx.alpha(rgb, a), t);
                        Gfx.line(ctx, mx2, my2, x1i, y1i, Gfx.alpha(rgb, a), t);
                    } else {
                        if (look.is("Glow")) Gfx.line(ctx, x0i, y0i, x1i, y1i, Gfx.alpha(rgb, a / 6), t + 2);
                        Gfx.line(ctx, x0i, y0i, x1i, y1i, Gfx.alpha(rgb, a), t);
                    }
                }
            }
        }
    }

    // ================================================================ PREDICTIONS (trajectory preview)
    public static final class PredictionsMod extends HudModule {
        final Setting.Mode look = add(new Setting.Mode("Line", 0, "Line", "Dots", "Dashed"));
        final Setting.Num thick = add(new Setting.Num("Thickness", 1, 1, 3, 1));
        final Setting.Num maxTicks = add(new Setting.Num("Max length (ticks)", 100, 20, 200, 10));
        final Setting.Bool marker = add(new Setting.Bool("Landing marker", true));
        final Setting.Bool dist = add(new Setting.Bool("Distance", true));
        final Setting.Col landing = add(new Setting.Col("Landing color", 0.38f, 0.7f, 1f));

        public PredictionsMod() {
            super("Predictions", "Preview of your arrow, pearl, trident and potion flight path.");
            category = Category.PLAYER;
            style.remove(opacity);
            style.remove(rounding);
            style.remove(effect);
        }

        /** returns {speed, gravity} or null */
        private float[] detect(MinecraftClient mc, ItemStack st) {
            if (st.isEmpty()) return null;
            var pl = mc.player;
            if (st.isOf(Items.BOW)) {
                if (!pl.isUsingItem() || !pl.getActiveItem().isOf(Items.BOW)) return null;
                float pw = BowItem.getPullProgress(pl.getItemUseTime());
                return pw < 0.1f ? null : new float[]{pw * 3.0f, 0.05f};
            }
            if (st.isOf(Items.CROSSBOW)) return CrossbowItem.isCharged(st) ? new float[]{3.15f, 0.05f} : null;
            if (st.isOf(Items.TRIDENT)) return pl.isUsingItem() && pl.getItemUseTime() >= 10 ? new float[]{2.5f, 0.05f} : null;
            if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) return new float[]{1.5f, 0.03f};
            if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) return new float[]{0.5f, 0.05f};
            if (st.isOf(Items.EXPERIENCE_BOTTLE)) return new float[]{0.7f, 0.07f};
            return null;
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            if (!CameraFx.cameraFresh() || mc.world == null) return;
            float[] pr = detect(mc, mc.player.getMainHandStack());
            if (pr == null) pr = detect(mc, mc.player.getOffHandStack());
            if (pr == null) return;

            double yaw = Math.toRadians(mc.player.getYaw()), pitch = Math.toRadians(mc.player.getPitch());
            double dx = -Math.sin(yaw) * Math.cos(pitch), dy = -Math.sin(pitch), dz = Math.cos(yaw) * Math.cos(pitch);
            double ex = mc.player.getX(), ey = mc.player.getEyeY(), ez = mc.player.getZ();
            double x = ex, y = ey - 0.1, z = ez;
            double vx = dx * pr[0], vy = dy * pr[0], vz = dz * pr[0];
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int rgb = accent() & 0xFFFFFF;
            int t = thick.asInt();
            float[] prev = null, cur = new float[3];
            boolean hit = false;
            double lx = x, ly = y, lz = z;
            int n = maxTicks.asInt();
            for (int i = 0; i < n; i++) {
                x += vx; y += vy; z += vz;
                if (solid(mc, x, y, z) || y < mc.world.getBottomY()) { hit = true; break; }
                vx *= 0.99; vy *= 0.99; vz *= 0.99; vy -= pr[1];
                lx = x; ly = y; lz = z;
                boolean ok = CameraFx.project(x, y, z, sw, sh, cur);
                if (ok && prev != null) {
                    boolean draw = switch (look.get()) { case "Dots" -> false; case "Dashed" -> (i / 2) % 2 == 0; default -> true; };
                    int col = Gfx.alpha(rgb, 230 - (int) (130f * i / n));
                    if (draw) Gfx.line(ctx, (int) prev[0], (int) prev[1], (int) cur[0], (int) cur[1], col, t);
                    else if (look.is("Dots") && i % 2 == 0) ctx.fill((int) cur[0] - 1, (int) cur[1] - 1, (int) cur[0] + 1, (int) cur[1] + 1, col);
                }
                if (ok) { if (prev == null) prev = new float[3]; prev[0] = cur[0]; prev[1] = cur[1]; prev[2] = cur[2]; }
                else prev = null;
            }
            float[] lp = new float[3];
            if ((hit || true) && marker.value && CameraFx.project(lx, ly, lz, sw, sh, lp)) {
                int lc = 0xFF000000 | landing.rgb();
                int cx = (int) lp[0], cy = (int) lp[1];
                Gfx.line(ctx, cx - 4, cy, cx, cy - 4, lc, 1); Gfx.line(ctx, cx, cy - 4, cx + 4, cy, lc, 1);
                Gfx.line(ctx, cx + 4, cy, cx, cy + 4, lc, 1); Gfx.line(ctx, cx, cy + 4, cx - 4, cy, lc, 1);
                ctx.fill(cx, cy, cx + 1, cy + 1, 0xFFFFFFFF);
                if (dist.value) {
                    double d = Math.sqrt((lx - ex) * (lx - ex) + (ly - ey) * (ly - ey) + (lz - ez) * (lz - ez));
                    String s = String.format(Locale.ROOT, "%.1fm", d);
                    TextRenderer tr = mc.textRenderer;
                    ctx.drawText(tr, s, cx - tr.getWidth(s) / 2, cy + 7, lc, true);
                }
            }
        }
    }

    // ================================================================ HOTBAR GLIDE
    public static final class HotbarGlideMod extends HudModule {
        final Setting.Mode look = add(new Setting.Mode("Style", 2, "Outline", "Fill", "Glow", "Pulse"));
        final Setting.Num speed = add(new Setting.Num("Speed", 14, 4, 40, 1));
        private float cur = -1f;
        private long lastNs;

        public HotbarGlideMod() {
            super("HotbarGlide", "Smooth sliding highlight when you scroll the hotbar.");
            style.remove(opacity);
            style.remove(rounding);
            style.remove(effect);
        }

        @Override
        public void draw(DrawContext ctx, MinecraftClient mc) {
            w = 0; h = 0;
            long ns = System.nanoTime();
            float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
            lastNs = ns;
            int sel = mc.player.getInventory().getSelectedSlot();
            if (cur < 0) cur = sel;
            cur += (sel - cur) * Math.min(1f, dt * speed.asFloat());
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            Player.highlight(ctx, Math.round(Player.hotbarX(sw, 0) + cur * 20f), Player.hotbarY(sh), look.get(), accent() & 0xFFFFFF);
        }
    }
}

package gordey.visuals.mixin;

import gordey.visuals.CameraFx;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private Vec3d pos;

    @Inject(method = "update", at = @At("RETURN"), require = 0)
    private void gordey$afterUpdate(CallbackInfo ci) {
        try {
            Vec3d np = CameraFx.apply((Camera) (Object) this, this.pos);
            if (np != null) this.pos = np;
            CameraFx.capture((Camera) (Object) this, this.pos);
        } catch (Throwable ignored) { }
    }
}

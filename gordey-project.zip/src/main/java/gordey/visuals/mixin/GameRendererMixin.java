package gordey.visuals.mixin;

import gordey.visuals.CameraFx;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void gordey$fov(CallbackInfoReturnable<Float> cir) {
        try {
            cir.setReturnValue(CameraFx.fovHook(cir.getReturnValue()));
        } catch (Throwable ignored) { }
    }
}

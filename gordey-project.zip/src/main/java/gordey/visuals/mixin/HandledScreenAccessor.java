package gordey.visuals.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(HandledScreen.class)
public interface HandledScreenAccessor {
    @Accessor("x") int gordey$getX();
    @Accessor("y") int gordey$getY();
    @Accessor("focusedSlot") Slot gordey$getFocusedSlot();
}

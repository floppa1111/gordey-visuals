package gordey.visuals.mixin;

import gordey.visuals.Player;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class LockClickMixin {
    @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true, require = 0)
    private void gordey$click(int syncId, int slotId, int button, SlotActionType actionType, PlayerEntity player, CallbackInfo ci) {
        try {
            if (Player.LockSlotMod.blockClick(slotId, actionType, player)) ci.cancel();
        } catch (Throwable ignored) { }
    }
}

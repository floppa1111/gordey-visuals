package gordey.visuals.mixin;

import gordey.visuals.Player;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class LockDropMixin {
    @Inject(method = "dropSelectedItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void gordey$drop(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (Player.LockSlotMod.blockHotbarDrop()) cir.setReturnValue(false);
        } catch (Throwable ignored) { }
    }
}

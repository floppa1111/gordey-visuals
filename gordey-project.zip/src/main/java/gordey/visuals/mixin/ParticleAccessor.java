package gordey.visuals.mixin;

import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Particle.class)
public interface ParticleAccessor {
    @Accessor("red") void gordey$setRed(float v);
    @Accessor("green") void gordey$setGreen(float v);
    @Accessor("blue") void gordey$setBlue(float v);
}

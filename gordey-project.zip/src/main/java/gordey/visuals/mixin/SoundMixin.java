package gordey.visuals.mixin;

import gordey.visuals.Player;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundManager.class)
public abstract class SoundMixin {
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void gordey$play(SoundInstance sound, CallbackInfo ci) {
        try {
            if (Player.SoundControllerMod.handle(sound)) ci.cancel();
        } catch (Throwable ignored) { }
    }
}

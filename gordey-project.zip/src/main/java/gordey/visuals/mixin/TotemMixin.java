package gordey.visuals.mixin;

import gordey.visuals.Player;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class TotemMixin {
    @Inject(method = "onEntityStatus", at = @At("HEAD"), require = 0)
    private void gordey$status(EntityStatusS2CPacket packet, CallbackInfo ci) {
        try {
            if (packet.getStatus() == 35) Player.TotemTrackerMod.onPop(packet.getEntity(MinecraftClient.getInstance().world));
        } catch (Throwable ignored) { }
    }
}
